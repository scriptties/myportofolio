from bardapi import Bard
import os

os.environ["_BARD_API_KEY"] = "ZAg2X4ldOFW_NnIOD6ei2VzF_Nlba-3bw2xVqaA4RquvVQMTJ5okk10Lsy8M-ztCaiQfWw."
message = input("Your Prompt: ")
print(Bard().get_answer(str(message))['content'])
