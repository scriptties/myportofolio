from bardapi import Bard
import streamlit as st
from streamlit_chat import message
import os

os.environ["_BARD_API_KEY"] = "ZAg2X4ldOFW_NnIOD6ei2VzF_Nlba-3bw2xVqaA4RquvVQMTJ5okk10Lsy8M-ztCaiQfWw."
# message = input("Your Prompt:")
# print(Bard().get_answer(str(message))['content'])

st.title("ARMAGEDDON")

def response_api(promot):
    print(Bard().get_answer(str(message))['content'])
    return message
def user_input():
    input_text = st.text_input("Your Prompt: ")
    return input_text

if 'generate' not in st.session_state:
    st.session_state['generate']=[]
if 'generate' not in st.session_state:
    st.session_state['past']=[]

user_text = user_input()

if user_text:
    output = response_api(user_text)
    st.session_state.generate.append(output)
    st.session_state.generate.append(user_text)

if st.session_state['generate']:
    for i in range(len(st.session_state['generate'])):
        message(st.session_state["past"][i], is_user=True, key=str(i) + '_user')
        message(st.session_state["generate"][i], key=str(i))