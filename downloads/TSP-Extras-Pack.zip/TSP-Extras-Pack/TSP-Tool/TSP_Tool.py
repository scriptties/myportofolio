import subprocess
import pyfiglet
import requests

text = pyfiglet.figlet_format("S.S.Scriptties' TSP Tool")
print(text)

def create_and_connect_to_vpn():
    p = subprocess.Popen(["sudo", "openvpn", "myvpn.conf"], shell=False)
    p.wait()

def do_option(option):
    if option == 1:
        print("Creating proxy server...")
        subprocess.call("sudo apt install proxychains", shell=True)
        subprocess.call("proxychains4 -f", shell=True)
    elif option == 2:
        print("Tracking IP...")
        ip = input("Enter the IP address: ")
        resp = requests.get(f"https://ipinfo.io/{ip}?token=e7ade9dd51e6ec")
        if resp.status_code == 200:
            data = resp.json()
            print(f"IP Address: {data['ip']}")
            print(f"City: {data['city']}")
            print(f"Region: {data['region']}")
            print(f"Country: {data['country']}")
            print("Timezone:", data['timezone'])
        else:
            print(f"Error: {resp.status_code}")
    elif option == 3:
        print("Starting Virtual Private Network...")
        create_and_connect_to_vpn()
    elif option == 4:
        print("Starting Apache&SQL Server For TSP")
        subprocess.call("sudo service apache2 start && sudo service mysql start", shell=True)
    elif option == 5:
        print("Exiting...")
        return None

def main():
    print("What would you like to do?")
    print("1. Create Proxy Server")
    print("2. Track IPs For TSPM")
    print("3. Start Virtual Private Network")
    print("4. Start Apache&SQL Server For TSP")
    print("5. Exit")

    option = int(input("Enter your choice: "))

    while option is not None:
        do_option(option)

        # Check if the `subprocess` and `pyfiglet` modules are installed
        try:
            import subprocess
            import pyfiglet
        except ImportError:
            # The modules are not installed, so install them
            print("The `subprocess` and `pyfiglet` modules are not installed.")
            print("I will now install them for you.")
            subprocess.call("pip install subprocess, pyfiglet", shell=True)

        print("What would you like to do?")
        print("1. Create Proxy Server")
        print("2. Track IPs For TSPM")
        print("3. Start Virtual Private Network")
        print("4. Start Apache&SQL Server For TSP")
        print("5. Exit")
        option = int(input("Enter your choice: "))

if __name__ == "__main__":
    main()
