<?php
include ('Article.php');        
$article = new Article();
$user_id = 123456;
if($_POST['id'] && $user_id) {	
	$articlesVote = $article->getArticleVotes($_POST['id']);		
	$userVote = $article->getUserVotes($user_id, $_POST['id']);		
	if($_POST['vote_type'] == 1) {
		if($article->isUserAlreadyVoted($user_id, $_POST['id']) && !$userVote['vote']) {
			$articlesVote['vote_up'] += 1;
			$articlesVote['vote_down'] -= 1;
			$userVote['vote'] = 1;	
		} else if (!$article->isUserAlreadyVoted($user_id, $_POST['id'])){
			$articlesVote['vote_up'] += 1;
			$userVote['vote'] = 1;	
		}		
	} else if($_POST['vote_type'] == 0) {
		if($article->isUserAlreadyVoted($user_id, $_POST['id']) && $userVote['vote']) {
			$articlesVote['vote_up'] -= 1;
			$articlesVote['vote_down'] += 1;
			$userVote['vote'] = 0;	
		} else if(!$article->isUserAlreadyVoted($user_id, $_POST['id'])) {
			$articlesVote['vote_down'] += 1;
			$userVote['vote'] = 0;				
		}		
	}	
	$articlesVoteData = array(
		'id' => $_POST['id'],
		'user_id' => $user_id,
		'vote_up' => $articlesVote['vote_up'],
		'vote_down' => $articlesVote['vote_down'],
		'user_vote' => $userVote['vote']	
	);	
	$articlesVoted = $article->updateArticleVote($articlesVoteData);	
	if($articlesVoted) {
		$response = array(
			'vote_up' => $articlesVote['vote_up'],
			'vote_down' => $articlesVote['vote_down'],
			'id' => $_POST['id']			
		);
		echo json_encode($response);
	}
}
?>