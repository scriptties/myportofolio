<?php 

$conn= new mysqli('sql109.infinityfree.com','if0_34786938','ZyJD1jzPenS','if0_34786938_deadtube')or die("Could not connect to mysql".mysqli_error($con));
