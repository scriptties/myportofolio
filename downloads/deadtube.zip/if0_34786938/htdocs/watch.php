<?php include 'db_connect.php' ?>
<?php
 function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
            $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
        $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$upload = $conn->query("SELECT up.*,concat(u.firstname,' ',u.lastname) as name,u.avatar FROM uploads up inner join users u on u.id =up.user_id where up.code = '{$_GET['code']}' ");
foreach ($upload->fetch_array() as $k => $v) {
	$$k = $v;
}
if(isset($_SESSION['login_id'])){
	if($_SESSION['login_id'] != $user_id){
		$chk = $conn->query("SELECT * FROM views where upload_id = '$id' and user_id ={$_SESSION['login_id']} ")->num_rows;
		if($chk <= 0){
			$conn->query("INSERT INTO views set upload_id = '$id' , user_id = {$_SESSION['login_id']}");
		}
	}
}else{
	$ip = getIPAddress();
	$chk = $conn->query("SELECT * FROM views where upload_id = '$id' and ip_address ='$ip' ")->num_rows;
	if($chk <= 0){
		$conn->query("INSERT INTO views set upload_id = '$id' , ip_address = '$ip'");
	}

}
$views = $conn->query("SELECT * FROM views where upload_id = '$id' ")->num_rows;
$conn->query("UPDATE uploads set total_views = $views where id = '$id' ");
 ?>
 <style type="text/css">
 	.suggested-img{
 		width: calc(30%);
 		height: 15vh;
 		display:flex;
 		justify-content: center;
 		align-items: center;
 		background: black
 	}
 	.suggested-details{
 		width: calc(70%);
 	}
 	.suggested-img video{
 		width: calc(100%);
 		height: calc(100%);
 	}
 	.suggested:hover{
 		background: #00adff1c;
 	}
 	#vid-watch{
 		max-height: 80vh
 	}
 </style>

<style>

</style>

<div class="container-fluid py-2">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">

		       <button class="" onclick="openPopup()" style="border: none;outline: none; width: 7.5%; height: auto; float: right;"><svg xmlns="http://www.w3.org/2000/svg" width="10%" height="10%" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> Comments</button>
               <button class="" style="border: none;outline: none; width: 7.5%; height: auto; float: right; margin-left: 20px;"><svg xmlns="http://www.w3.org/2000/svg" width="10%" height="10%" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg> Cast</button>
<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->



<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

               <button class="" style="border: none;outline: none; width: 10%; height: auto; float: right;"><svg xmlns="http://www.w3.org/2000/svg" width="10%" height="10%" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"></path></svg> Follow</button>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="script/vote.js"></script>

<div class="container" style="float: left;">
  <div class="row" id="article-list">

    <?php
    include('Article.php');
    $article = new Article();
    $articlesData = $article->getArticles();
    $targetArticleID = $_GET['code']; // Get the article ID from the URL parameter

    foreach ($articlesData as $article) {
      if ($article['code'] === $targetArticleID) {
        ?>
        <div style=" position: relative;top: -20px;" class="col-sm-4 col-lg-4 col-md-4 article-body">
          <div class="article-options pull-right">
		  <a class="options" data-vote-type="1" id="article_vote_up_<?php echo $article['id']; ?>"><button style="border: none;outline: none; width: 33%; height: auto; float: left; margin-right: 20px;"><svg xmlns="http://www.w3.org/2000/svg" width="10%" height="10%" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg> Like  <span class="counter" id="vote_up_count_<?php echo $article['id']; ?>">&nbsp;&nbsp;<?php echo $article['vote_up']; ?></span>&nbsp;&nbsp;&nbsp;</button></a>
          <a class="options" data-vote-type="0" id="article_vote_down_<?php echo $article['id']; ?>"><button style="border: none;outline: none; width: 33%; height: auto; float: left;"><svg xmlns="http://www.w3.org/2000/svg" width="10%" height="10%" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path></svg> Dislike  <span class="counter" id="vote_down_count_<?php echo $article['id']; ?>">&nbsp;&nbsp;<?php echo $article['vote_down']; ?></span></button></a>
	      </div>
	    </div>
        <?php
        break; // Exit the loop after finding the target article
      }
    }
    ?>
  </div>
</div>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

			<br><br><br><br>
				<div class="row">
					<div class="col-md-8">
						<div class="d-block w-100 vid-watch-feild bg-dark border border-dark p-0" style="border-width: 2px">
							<video class="w-100" autoplay="true" controls id="vid-watch">
								<source src="<?php echo "assets/uploads/videos/".$video_path ?>">
							</video>
<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->


<style>

ul {
	list-style-type: none;
}

.comment-row {
	border-bottom: #e0dfdf 1px solid;
	margin-bottom: 15px;
	padding: 15px;
}

.outer-comment {
	background: #F0F0F0;
	padding: 20px;
	border: #dedddd 1px solid;
	border-radius: 4px;
}

span.comment-row-label {
	color: #484848;
}

span.posted-by {
	font-weight: bold;
}

.comment-info {
	font-size: 0.9em;
}

.btn-reply {
	color: #2f20d1;
	cursor: pointer;
	text-decoration: none;
}

.btn-reply:hover {
	text-decoration: underline;
}

</style>
<script src="jquery-3.2.1.min.js"></script>


		<form id="frm-comment">
			<div class="input-row">
				<input type="hidden" name="comment_id" id="commentId" /> <input
					class="input-field" type="hidden" name="name" id="name"
					placeholder="Enter your name" value="Anonymous"></input><br>
			    <button onclick="openPopup()" style='background-color: #F5F5F5; width:10%; height:22.5px; text-align: center; border: none;outline: none;'> Comment </button>
				<input style="border: none;outline: none;width:76.2%; height:22.5px;" class="input-field" name="comment" id="comment"
					placeholder="Your comment here"></input>
				<input style="border: none;outline: none; height:22.5px;" type="button" class="btn-submit" id="submitButton"
					value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Send&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" ></input>
			</div>
		</form>
	
		<script>
            function postReply(commentId) {
                $('#commentId').val(commentId);
                $("#name").focus();
            }

            $("#submitButton").click(function () {
            	   $("#comment-message").css('display', 'none');
                var str = $("#frm-comment").serialize();

                $.ajax({
                    url: "comment-add.php",
                    data: str,
                    type: 'post',
                    success: function (response)
                    {
                        var result = eval('(' + response + ')');
                        if (response)
                        {
                        	$("#comment-message").css('display', 'inline-block');
                            $("#name").val("");
                            $("#comment").val("");
                            $("#commentId").val("");
                     	   listComment();
                        } else
                        {
                            alert("Failed to add comments !");
                            return false;
                        }
                    }
                });
            });
            
            $(document).ready(function () {
            	   listComment();

            });

            function listComment() {
                $.post("comment-list.php",
                        function (data) {
                           var data = JSON.parse(data);
                            
                            var comments = "";
                            var replies = "";
                            var item = "";
                            var parent = -1;
                            var results = new Array();

                            var list = $("<ul class='outer-comment'>");
                            var item = $("<li>").html(comments);

                            for (var i = 0; (i < data.length); i++)
                            {
                                var commentId = data[i]['comment_id'];
                                parent = data[i]['parent_comment_id'];

                                if (parent == "0")
                                {
                                    comments = "<div class='comment-row'>"+
                                    "<div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'>" + data[i]['comment_sender_name'] + " </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['comment_at'] + "</span></div>" + 
                                    "<div class='comment-text'>" + data[i]['comment'] + "</div>"+
                                    "<div><a class='btn-reply' onClick='postReply(" + commentId + ")'>Reply</a></div>"+
                                    "</div>";

                                    var item = $("<li>").html(comments);
                                    list.append(item);
                                    var reply_list = $('<ul>');
                                    item.append(reply_list);
                                    listReplies(commentId, data, reply_list);
                                }
                            }
                            $("#output").html(list);
                        });
            }

            function listReplies(commentId, data, list) {
                for (var i = 0; (i < data.length); i++)
                {
                    if (commentId == data[i].parent_comment_id)
                    {
                        var comments = "<div class='comment-row'>"+
                        " <div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'> Anonymous </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['comment_at'] + "</span></div>" + 
                        "<div class='comment-text'>" + data[i]['comment'] + "</div>"+
                        "<div><a class='btn-reply' onClick='postReply(" + data[i]['comment_id'] + ")'>Reply</a></div>"+
                        "</div>";
                        var item = $("<li>").html(comments);
                        var reply_list = $('<ul>');
                        list.append(item);
                        item.append(reply_list);
                        listReplies(data[i].comment_id, data, reply_list);
                    }
                }
            }
        </script>

<style>
.popup {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: none;
}
.popup-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  height: 200px;
  background-color: white;
  padding: 20px;
  overflow-y: scroll;
}
.close-button {
  position: sticky;
  top: 10px;
  right: 10px;
  font-size: 18px;
  color: #000;
  cursor: pointer;
  z-index: 1001;

}
.c {border-radius: 50%;}
</style>

<div class="popup" id="popup">
<div class="popup-content">

<div id="output"></div>

<button style="border: none;outline: none;background-color:red;color:white;position: fixed;" class="close-button c" onclick="closePopup()">&nbsp;X&nbsp;</button>
</div>
</div>
<script>
function openPopup() {
  document.getElementById("popup").style.display = "block";
}
function closePopup() {
  document.getElementById("popup").style.display = "none";
}
</script>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
						</div>
						<div class="col-md-12 py-2">
							<div class="row">
								<h5 class="text-dark"><b><?php echo $title ?></b></h5>
							</div>
						</div>
						<div class="col-md-12">
							<div class="row">
								<span class="badge badge-white"><b><?php echo date("M d, Y",strtotime($date_created)) ?></b></span>
								<span class="badge badge-primary"><b><?php echo $views.($views > 1 ? ' views':' view') ?></b></span>
							</div>
						</div>
						<hr>
						<div class="col-md-12">
							<div class="d-flex w-100 align-items-center">
								<?php if(!empty($avatar)): ?>
									<img src="assets/uploads/<?php echo $avatar ?>" class="rounded-circle" width="50px" height="50px" alt="">
								<?php else: ?>
									<span class="d-flex justify-content-center bg-primary align-items center rounded-circle border py-2 px-3" ><h3 class="text-white m-0"><b><?php echo substr($name,0,1) ?></h3></b></span>
								<?php endif; ?>
									<h6 class="mx-3"><b><?php echo $name ?></b></h6>
							</div>
							<h5><b>Description</b></h5>
							<p><?php echo str_replace(array("\n","\r"),'<br/>',$description) ?></p>
						</div>
					</div>
					<div class="col-md-4 border-left">
						<?php 
							$qry = $conn->query("SELECT * FROM uploads where id !=$id order by total_views asc,rand() limit 10");
							while($row= $qry->fetch_assoc()):
						?>
						<a class="d-flex w-100 border-bottom pb-1 suggested" href="index.php?page=watch&code=<?php echo $row['code'] ?>">
							<div class="img-thumbnail suggested-img border-dark border" poster="assets/uploads/thumbnail/<?php echo $row['thumbnail_path'] ?>">
								<video class="img-fluid" id="<?php echo $row['code'] ?>" muted>
									<source src="assets/uploads/videos/<?php echo $row['video_path'] ?>" alt="" >
								</video>
							</div>
							<div class="suggested-details px-2 py-2">
								<h6 class="truncate-2 text-dark"><b><?php echo $row['title'] ?></b></h6>
								<small class="text-muted"><i>Posted:<?php echo date("M, d Y",strtotime($row['date_created'])) ?></i></small>
							</div>
						</a>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('.suggested').hover(function(){
		$(this).addClass('active')
		var vid = $(this).find('video')
		var id = vid.get(0).id;
			setTimeout(function(){
				vid.trigger('play')
				document.getElementById(id).playbackRate = 2.0
			},500)
	})
	$('.suggested').mouseout(function(){
		var vid = $(this).find('video')
			setTimeout(function(){
				vid.trigger('pause')
			},500)
	})
</script>


