<?php
class Article{
    private $host  = 'localhost';
    private $user  = 'root';
    private $password   = '';
    private $database  = 'vss_db';    
    private $articlesTable = 'uploads';
	private $articlesVotesTable = 'likes';
	private $dbConnect = false;
    public function __construct(){
        if(!$this->dbConnect){ 
            $conn = new mysqli($this->host, $this->user, $this->password, $this->database);
            if($conn->connect_error){
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            }else{
                $this->dbConnect = $conn;
            }
        }
    }
	private function executeQuery($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$data= array();
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$data[]=$row;            
		}
		return $data;
	}
	public function getArticles(){
		$sqlQuery = 'SELECT id, code, vote_up, vote_down 
			FROM '.$this->articlesTable;
		return  $this->executeQuery($sqlQuery);        
	}		
	public function isUserAlreadyVoted($user_id, $id){
		$sqlQuery = 'SELECT code, user_id, vote FROM '.$this->articlesVotesTable." 
			WHERE user_id = '".$user_id."' AND code = '".$id."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
        return  mysqli_num_rows($result);
	}		
	public function getUserVotes($user_id, $id){
		$sqlQuery = 'SELECT code, user_id, vote 
			FROM '.$this->articlesVotesTable." 
			WHERE user_id = '".$user_id."' AND code = '".$id."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
        return  mysqli_fetch_array($result, MYSQLI_ASSOC);
	}	
	public function getArticleVotes($id){
		$sqlQuery = 'SELECT id, user_id, vote_up, vote_down 
			FROM '.$this->articlesTable." 
			WHERE id = '".$id."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
        return  mysqli_fetch_array($result, MYSQLI_ASSOC);
	}	
	public function updateArticleVote($articleVoteData) {	
		$sqlQuery = "UPDATE ".$this->articlesTable." 
			SET vote_up = '".$articleVoteData['vote_up']."' , vote_down = '".$articleVoteData['vote_down']."' 
			WHERE id = '".$articleVoteData['id']."'";
		mysqli_query($this->dbConnect, $sqlQuery);		
		$sqlVoteQuery = '';
		if($this->isUserAlreadyVoted($articleVoteData['user_id'], $articleVoteData['id'])) {
			$sqlVoteQuery = "UPDATE ".$this->articlesVotesTable." 
				SET vote = '".$articleVoteData['user_vote']."' 
				WHERE code = '".$articleVoteData['id']."' AND user_id = '".$articleVoteData['user_id']."'";
		} else {
			$sqlVoteQuery = "INSERT INTO ".$this->articlesVotesTable." (id, code, user_id, vote) 
				VALUES ('', '".$articleVoteData['id']."', '".$articleVoteData['user_id']."', '".$articleVoteData['user_vote']."')";
		}
		if($sqlVoteQuery) {
			mysqli_query($this->dbConnect, $sqlVoteQuery);	
			return true;			
		}		
	}
}
?>