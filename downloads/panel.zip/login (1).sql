-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2024 at 07:55 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `account_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `email`, `account_password`) VALUES
(2, 's.s.scriptties', 'sexyselloutteam@gmail.com', 'm22112405'),
(3, 'Mohammed Essam', 'mohammedmastergamer@hotmail.com', 'm22112405'),
(4, 'Essam Mohamed', 'cyberdeer224200@gmail.com', 'm22112405');

-- --------------------------------------------------------

--
-- Table structure for table `file_manager`
--

CREATE TABLE `file_manager` (
  `id` int(11) NOT NULL,
  `file_name` varchar(125) DEFAULT NULL,
  `real_name` varchar(125) DEFAULT NULL,
  `file_size` varchar(45) DEFAULT NULL,
  `file_type` varchar(45) DEFAULT NULL,
  `folder` int(11) DEFAULT NULL,
  `createdOn` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `file_manager`
--

INSERT INTO `file_manager` (`id`, `file_name`, `real_name`, `file_size`, `file_type`, `folder`, `createdOn`) VALUES
(1, '9psob3.pdf', 'Political_Compass_Certificate_286f.pdf', '3580995', 'application/pdf', NULL, '2024-10-31 21:23:48'),
(2, 'agrq1l.png', 'S.S.S anomalies icon.png', '78059', 'image/png', 6, '2024-10-31 22:30:32');

-- --------------------------------------------------------

--
-- Table structure for table `file_manager_folder`
--

CREATE TABLE `file_manager_folder` (
  `id` int(11) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `name` varchar(125) DEFAULT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `file_manager_folder`
--

INSERT INTO `file_manager_folder` (`id`, `parent`, `name`, `createdOn`) VALUES
(1, NULL, 'Websites', '2024-10-31 18:35:34'),
(2, NULL, 'Games', '2024-10-31 18:35:51'),
(3, NULL, 'Tools', '2024-10-31 18:35:58'),
(4, NULL, 'Scripts', '2024-10-31 18:36:39'),
(5, NULL, 'Bots', '2024-10-31 18:36:51'),
(6, NULL, 'Images', '2024-10-31 18:37:17'),
(7, NULL, 'Software', '2024-10-31 18:39:01'),
(8, NULL, 'Freelancing', '2024-10-31 18:39:34'),
(9, 1, 'Portfolio', '2024-10-31 19:22:28'),
(10, 1, 'Discord bot panel', '2024-10-31 19:22:50'),
(11, 1, 'Platform', '2024-10-31 19:23:02'),
(12, 1, 'Search Engine', '2024-10-31 19:23:20'),
(13, 1, 'Dead Tube', '2024-10-31 19:24:36'),
(14, 1, 'Niamh\'s Birthday', '2024-10-31 19:25:05'),
(15, 1, 'ERC-20 token', '2024-10-31 19:25:39'),
(16, 2, 'Today', '2024-10-31 19:27:28'),
(17, 2, 'Safe Haven', '2024-10-31 19:27:36'),
(18, 2, 'One Night At Scriptties', '2024-10-31 19:27:53'),
(19, 2, 'TSPM', '2024-10-31 19:28:29'),
(20, NULL, 'Addons', '2024-10-31 19:29:01');

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `link`) VALUES
(1, 'dedede'),
(2, 'yyyyyyy');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `id` int(11) NOT NULL,
  `server_name` varchar(255) NOT NULL,
  `server_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `server_name`, `server_link`) VALUES
(5, 'server test', 'google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `post_title` text NOT NULL,
  `post_description` text NOT NULL,
  `post_status` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'Mohamed.Menayyir24', 'Mm@54321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file_manager`
--
ALTER TABLE `file_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file_manager_folder`
--
ALTER TABLE `file_manager_folder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `file_manager`
--
ALTER TABLE `file_manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `file_manager_folder`
--
ALTER TABLE `file_manager_folder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
