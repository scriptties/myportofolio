<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$account_password = $_POST['account_password'];

// Prepare and execute an INSERT statement
$sql = "INSERT INTO accounts (name, email, account_password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $name, $email, $account_password);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Account added successfully!";
    header("Location: accounts.php");
} else {
    echo "Error adding account: " . $stmt->error;
}

$stmt->close();
$conn->close();
