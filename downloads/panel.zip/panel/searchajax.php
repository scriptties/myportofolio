//live-search/search.php

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $sql = $search ?
        "SELECT id, name, email, account_password FROM accounts WHERE name LIKE '%$search%'" :
        "SELECT id, name, email, account_password FROM accounts";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td><i class='fa-solid fa-user'></i>&nbsp;" . $row['name'] . "</td><td>" . $row['email'] . "</td><td>" . $row['account_password'] . "&nbsp;&nbsp;<a href='delete_accounts.php?id=". $row["id"]."' class='link-dark'><i class='fa-solid fa-trash fs-5'></i></a></td></tr>";
        }
    } else {
        echo "<tr><td colspan='1'>No results found.</td></tr>";
    }
}

$conn->close();
?>