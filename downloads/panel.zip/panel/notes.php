<?php

require 'UserInfo.php';
require 'function.php';
if(isset($_SESSION["id"])){
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
}
else{
  header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Control Panel | S.S.S</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
        <script src="https://kit.fontawesome.com/33e24c6df0.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      
    </head>
    <body>
        <div class="header">
            <br>
            &nbsp;&nbsp;&nbsp; <img src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png" width="50px" height="auto"> Scriptties Control Panel
        </div>
        <br><br>
        <ul>
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="filemanager.php"><i class="fa-solid fa-folder"></i> Files</a></li>
            <li><a href="servers.php"><i class="fa-solid fa-server"></i> Servers</a></li>
            <li><a href="databases.php"><i class="fa-solid fa-database"></i> DataBases</a></li>
            <li><a href="accounts.php"><i class="fa-solid fa-users-gear"></i> Accounts</a></li>
            <li><a  class="active" href=""><i class="fa-solid fa-clipboard"></i> Notes</a></li>
            <li style="float:right"><a href="profile.php"><img src="PFP.png" width="25px"> <?php echo $user["username"]; ?></a></li>
            <li style="float:right"><a href="links.php"><i class="fa-solid fa-link"></i> Links</a></li>
        </ul>
<style>
a {
    color: black;
}

input[type="text"] {
    width: 300px;
    padding: 10px;
    font-size: 16px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

th,
td {
    border: 1px solid #ddd;
    padding: 10px;
}

th {
    background-color: white;
    color: black;
}
</style>
        <section class="page">
            <h1>Notes Management</h1>
            <div style="
            background-color: white;
            color: black;
            width: 40%;
            padding: 25px;
            text-align: left;">
           <div class="container">  
                <div class="form-group">  
                     <input type="hidden" name="post_title" id="post_title" class="form-control" value="note" />  
                </div>  
                <div class="form-group">   
                    <textarea style="padding: 30px; width: 90%;" name="post_description" id="post_description" rows="6" class="form-control"></textarea>  
                </div>
                <div class="form-group">  
                     <input type="hidden" name="post_id" id="post_id" />  
                     <div id="autoSave"></div>  
                </div>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      function autoSave()  
      {  
           var post_title = $('#post_title').val();  
           var post_description = $('#post_description').val();  
           var post_id = $('#post_id').val();  
           if(post_title != '' && post_description != '')  
           {  
                $.ajax({  
                     url:"save_post.php",  
                     method:"POST",  
                     data:{postTitle:post_title, postDescription:post_description, postId:post_id},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                          if(data != '')  
                          {  
                               $('#post_id').val(data);  
                          }  
                          $('#autoSave').text("Note saved as draft");  
                          setInterval(function(){  
                               $('#autoSave').text('');  
                          }, 5000);  
                     }  
                });  
           }            
      }  
      setInterval(function(){   
           autoSave();   
           }, 10000);  
 });  
 </script>
 
            <p style="">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-rotate-right fa-spin"></i> AutoSaving...
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-check"></i> Note Drafts
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-check"></i> Resizable
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button id="clearTable">Clear All</button>
            </p>
            <style>
                .notes {
                    width: 95%;
                    background-color: whitesmoke;
                    padding: 10px;
                }
            </style>
<div class='notes'>
<h1>NOTES</h1>
-------------------------------------------------------------------------------------------
<div id="post-container"></div>
</div>

<script>
    function loadPosts() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'saved_notes.php'); // Replace with your PHP script
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById('post-container').innerHTML = xhr.responseText;
            } else {
                console.error('Request failed.  Returned status of ' + xhr.status);
            }
        };
        xhr.send();
    }

    // Initial load
    loadPosts();

    // Set up an interval to fetch data periodically (adjust interval as needed)
    setInterval(loadPosts, 5000); // Fetch every 5 seconds
</script>

<script>
    document.getElementById("clearTable").addEventListener("click", function() {
        if (confirm("Are you sure you want to clear notes?")) {
            // Send an AJAX request to the PHP script
            fetch("clear_notes.php")
                .then(response => response.text())
                .then(data => {
                    alert(data); // Display the success or error message
                    // Optionally, reload the page or update the table display
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while clearing the table.");
                });
        }
    });
</script>
            </div>
        </section>
    </body>
</html>


