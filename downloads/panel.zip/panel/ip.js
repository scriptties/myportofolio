const token = "116f79170a609e"; // Replace with your actual token
const infoElement = document.getElementById("ip");

fetch(`https://ipinfo.io/json?token=${token}`)
  .then(response => response.json())
  .then(data => {
    const ip = data.ip;
    const hostname = data.hostname;
    const city = data.city;
    const region = data.region;
    const country = data.country;
    const loc = data.loc;
    const org = data.org;
    const postal = data.postal;
    const timezone = data.timezone;
    const isp = data.isp;
    const mobile = data.mobile;
    const proxy = data.proxy;
    const vpn = data.vpn;
    const domain = data.domain;

    infoElement.innerHTML = `
      <p><strong>IP Address:</strong> ${ip}</p>
      <p><strong>Hostname:</strong> ${hostname}</p>
      <p><strong>City:</strong> ${city}</p>
      <p><strong>Region:</strong> ${region}</p>
      <p><strong>Country:</strong> ${country}</p>
      <p><strong>Location:</strong> ${loc}</p>
      <p><strong>Organization:</strong> ${org}</p>
      <p><strong>Postal Code:</strong> ${postal}</p>
      <p><strong>Timezone:</strong> ${timezone}</p>
      <p><strong>ISP:</strong> ${isp}</p>
      <p><strong>Mobile:</strong> ${mobile}</p>
      <p><strong>Proxy:</strong> ${proxy}</p>
      <p><strong>VPN:</strong> ${vpn}</p>
      <p><strong>Domain:</strong> ${domain}</p>
    `;
  })
  .catch(error => {
    console.error("Error fetching data:", error);
    infoElement.innerHTML = "<p>Error fetching data. Please check your token.</p>";
  });

