<?php

require 'UserInfo.php';
require 'function.php';
if(isset($_SESSION["id"])){
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
}
else{
  header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Control Panel | S.S.S</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
        <script src="https://kit.fontawesome.com/33e24c6df0.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="header">
            <br>
            &nbsp;&nbsp;&nbsp; <img src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png" width="50px" height="auto"> Scriptties Control Panel
        </div>
        <br><br>
        <ul>
            <li><a class="active" href=""><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="filemanager.php"><i class="fa-solid fa-folder"></i> Files</a></li>
            <li><a href="servers.php"><i class="fa-solid fa-server"></i> Servers</a></li>
            <li><a href="databases.php"><i class="fa-solid fa-database"></i> DataBases</a></li>
            <li><a href="accounts.php"><i class="fa-solid fa-users-gear"></i> Accounts</a></li>
            <li><a href="notes.php"><i class="fa-solid fa-clipboard"></i> Notes</a></li>
            <li style="float:right"><a href="profile.php"><img src="PFP.png" width="25px"> <?php echo $user["username"]; ?></a></li>
            <li style="float:right"><a href="links.php"><i class="fa-solid fa-link"></i> Links</a></li>
        </ul>
        <section class="page">
    <div style="
            background-color: white;
            color: black;
            width: 50%;
            padding: 25px;
            text-align: left;">
    <h2><i class="fa-solid fa-hard-drive"></i> Disk Usage</h2>
    <div id="piechart"></div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <?php
    $diskUsage = disk_free_space("/");
    $diskTotal = disk_total_space("/");
    $diskPercent = round(($diskTotal - $diskUsage) / $diskTotal * 100, 2);
    echo "Disk Usage: " . $diskPercent . "%";
    ?>
    </div><br>
    <div style="
            background-color: white;
            color: black;
            width: 50%;
            padding: 25px;
            text-align: left;">
<div id="myChart" style="width:100%; max-width:600px; height:500px;"></div>

<script>
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
const data = google.visualization.arrayToDataTable([
  ['Contry', 'Mhl'],
  ['PHP',55],
  ['JavaScript',49],
  ['HTML',44],
  ['CSS',24],
  ['MySQL',15]
]);

const options = {
  title:'Languages Used'
};

const chart = new google.visualization.BarChart(document.getElementById('myChart'));
  chart.draw(data, options);
}
</script>

    </div>
        </section>
    </body>
</html>


