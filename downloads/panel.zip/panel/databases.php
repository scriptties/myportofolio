<?php

require 'UserInfo.php';
require 'function.php';
if(isset($_SESSION["id"])){
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
}
else{
  header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Control Panel | S.S.S</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
        <script src="https://kit.fontawesome.com/33e24c6df0.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="header">
            <br>
            &nbsp;&nbsp;&nbsp; <img src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png" width="50px" height="auto"> Scriptties Control Panel
        </div>
        <br><br>
        <ul>
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="filemanager.php"><i class="fa-solid fa-folder"></i> Files</a></li>
            <li><a href="servers.php"><i class="fa-solid fa-server"></i> Servers</a></li>
            <li><a class="active" href=""><i class="fa-solid fa-database"></i> DataBases</a></li>
            <li><a href="accounts.php"><i class="fa-solid fa-users-gear"></i> Accounts</a></li>
            <li><a href="notes.php"><i class="fa-solid fa-clipboard"></i> Notes</a></li>
            <li style="float:right"><a href="profile.php"><img src="PFP.png" width="25px"> <?php echo $user["username"]; ?></a></li>
            <li style="float:right"><a href="links.php"><i class="fa-solid fa-link"></i> Links</a></li>
        </ul>
        <section class="page">
        <style type="text/css">
			td{
				padding: 30px;
			}
			.btn{
				padding: 10px;
				color: #fff;
				background-color: #000;
				width: 120px;
				border: none;
				cursor: pointer;
			}
		</style>
		<div style="
    background-color: white;
    color: black;
    width: 50%;
    padding: 25px;
    text-align: left;">
			<h1>Database Share</h1>
			<h4 style="color:red;">Make Sure both Sender and receiver are connected to the same network</h4><br><br>
			<a href="send.php" ><input class="btn" type="button" value="Add" /></a><br/><br/>
			<a href="receive.php" ><input class="btn" type="button" value="Download" /></a><br><br><br>
            <p>"Add" sends the sharer to a page to choose the file, when the file is shared it goes to shared.php where databases will be shared till they are cancelled, deleted, or sharing is stopped.<br><br><br>
            "download" sends the user to a page where you can download all the databases the sharer is currently sharing and hasn't deleted or stopped.</p>
		</div>
        </section>
    </body>
</html>


