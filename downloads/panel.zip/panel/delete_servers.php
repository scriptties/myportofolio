<?php
include "function.php";
$id = $_GET["id"];
$sql = "DELETE FROM `servers` WHERE id = $id";
$result = mysqli_query($conn, $sql);

if ($result) {
  header("Location: servers.php?msg=Data deleted successfully");
} else {
  echo "Failed: " . mysqli_error($conn);
}