<?php

require 'UserInfo.php';
require 'function.php';
if(isset($_SESSION["id"])){
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
}
else{
  header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Control Panel | S.S.S</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
        <script src="https://kit.fontawesome.com/33e24c6df0.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    </head>
    <body>
        <div class="header">
            <br>
            &nbsp;&nbsp;&nbsp; <img src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png" width="50px" height="auto"> Scriptties Control Panel
        </div>
        <br><br>
        <ul>
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="filemanager.php"><i class="fa-solid fa-folder"></i> Files</a></li>
            <li><a class="active" href=""><i class="fa-solid fa-server"></i> Servers</a></li>
            <li><a href="databases.php"><i class="fa-solid fa-database"></i> DataBases</a></li>
            <li><a href="accounts.php"><i class="fa-solid fa-users-gear"></i> Accounts</a></li>
            <li><a href="notes.php"><i class="fa-solid fa-clipboard"></i> Notes</a></li>
            <li style="float:right"><a href="profile.php"><img src="PFP.png" width="25px"> <?php echo $user["username"]; ?></a></li>
            <li style="float:right"><a href="links.php"><i class="fa-solid fa-link"></i> Links</a></li>
        </ul>
        <section class="page">
        <h1>Server Management</h1>
<style>
a {
    color: black;
}

input[type="text"] {
    width: 300px;
    padding: 10px;
    font-size: 16px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

th,
td {
    border: 1px solid #ddd;
    padding: 10px;
}

th {
    background-color: white;
    color: black;
}
</style>

<p><strong>Add Servers</strong></p>
<form action="insert_server.php" method="post" style="
    background-color: white;
    color: black;
    width: 50%;
    padding: 25px;
    text-align: left;">
  <input type="text" id="server_name" name="server_name" placeholder="Server Name" required><br><br>
  <input type="text" id="server_link" name="server_link" placeholder="Server URL" required><br><br>
  <input type="submit" value="Add Server">
  <button id="clearTable">Clear All</button>
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <p><strong>Server List</strong></p>
    <div style="
    background-color: white;
    color: black;
    width: 50%;
    padding: 25px;
    text-align: left;">
    <input type="text" id="search" placeholder="Search...">
    <table id="result">
        <thead>
            <tr>
                <th>Servers</th>
                <th>actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Initial data will be loaded here -->
        </tbody>
    </table>

    <script>
        $(document).ready(function () {
            // Load all records initially
            loadAllRecords();

            // Perform search
            $('#search').on('keyup', function () {
                var query = $(this).val();
                if (query.length > 2) {
                    $.ajax({
                        url: 'search.php',
                        type: 'POST',
                        data: { search: query },
                        success: function (data) {
                            $('#result tbody').html(data);
                        }
                    });
                } else {
                    loadAllRecords();
                }
            });

            function loadAllRecords() {
                $.ajax({
                    url: 'search.php',
                    type: 'POST',
                    data: { search: '' },
                    success: function (data) {
                        $('#result tbody').html(data);
                    }
                });
            }
        });
    </script>
<script>
    document.getElementById("clearTable").addEventListener("click", function() {
        if (confirm("Are you sure you want to clear servers?")) {
            // Send an AJAX request to the PHP script
            fetch("clear_servers.php")
                .then(response => response.text())
                .then(data => {
                    alert(data); // Display the success or error message
                    // Optionally, reload the page or update the table display
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while clearing the table.");
                });
        }
    });
</script>
    </div>

        </section>
    </body>
</html>

