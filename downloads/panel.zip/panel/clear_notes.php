<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); 

}

// SQL query to truncate the table
$sql = "TRUNCATE TABLE tbl_post";

if ($conn->query($sql) === TRUE) {
    echo "notes truncated successfully";
} else {
    echo "Error truncating table: " . $conn->error;
}

$conn->close();