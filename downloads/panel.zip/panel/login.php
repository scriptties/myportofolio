<?php
require 'function.php';
if(isset($_SESSION["id"])){
 header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<title>Control Panel | S.S.S</title>
<link rel="stylesheet" href="style.css">
<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
</head>
<body>
<div class="header">
<br>
&nbsp;&nbsp;&nbsp; <img src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png" width="50px" height="auto"> Scriptties Control Panel
</div>
<br><br><br><br><br><br><br>
<center>
<h2>Login</h2>
<form autocomplete="off" action="" method="post" style="
background-color: white;
color: black;
width: 20%;
padding: 25px;">
<center>
<input type="hidden" id="action" value="login">

<input type="text" id="username" value="" placeholder="username"> <br><br>

<input type="password" id="password" value="" placeholder="password"> <br><br>

<button type="button" onclick="submitData();">Login</button>
</center>
</form>
<br>
<?php require 'script.php'; ?>
</body>
</html>