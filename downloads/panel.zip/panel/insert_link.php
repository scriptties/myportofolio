<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$link = $_POST['link'];

// Prepare and execute an INSERT statement
$sql = "INSERT INTO links (link) VALUES (?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $link);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Link added successfully!";
    header("Location: links.php");
} else {
    echo "Error adding link: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>