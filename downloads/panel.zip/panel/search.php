<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $sql = $search ?
        "SELECT id, server_name, server_link FROM servers WHERE server_name LIKE '%$search%'" :
        "SELECT id, server_name, server_link FROM servers";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td> <i class='fa-solid fa-server'></i> <a href=" . $row['server_link'] . ">" . $row['server_name'] . "</a><td><a href='delete_servers.php?id=". $row["id"]."' class='link-dark'><i class='fa-solid fa-trash fs-5'></i> Delete</a></td></tr>";
        }
    } else {
        echo "<tr><td colspan='1'>No results found.</td></tr>";
    }
}

$conn->close();