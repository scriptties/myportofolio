<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";
                        
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT id, post_description FROM tbl_post";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo  "".$row['post_description']."<br><br><a href='delete_notes.php?id=". $row["id"]."' class='link-dark'><i class='fa-solid fa-trash fs-5'></i> Delete</a><br>-------------------------------------------------------------------------------------------<br>";
    }
}

$conn->close();