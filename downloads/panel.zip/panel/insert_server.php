<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$server_name = $_POST['server_name'];
$server_link = $_POST['server_link'];

// Prepare and execute an INSERT statement
$sql = "INSERT INTO servers (server_name, server_link) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $server_name, $server_link);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Server added successfully!";
    header("Location: servers.php");
} else {
    echo "Error adding server: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>