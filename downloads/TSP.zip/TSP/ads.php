<?php
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

session_start();

include("connection.php");
include("functions.php");
include("config.php");


$user_data = check_login($con);
$user_data = check_key($con);


?>



<!DOCTYPE html>
<html>
<head>
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">



<style>
html {
  font-size: 15px;
}
</style>

    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>

<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>
    
<title>Ads | S.S.S</title>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<?php
if (isset($_POST['post_comment'])) {

    $name = $_POST['name'];
    $message = $_POST['message'];
    
    $sql = "INSERT INTO comments (name, message)
    VALUES ('$name', '$message')";

    if ($con->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error: " . $sql . "<br>" . $con->$error;
    }
}
?>
<br>

<style>

* { margin: 0; padding: 0; box-sizing: border-box; }



.wrapper {
	background: white;
	border-radius: 10px;
	width: 30%;
	height: auto;
	display: flex;
	justify-content: center;
	align-items: center;
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	border:solid 3px grey;
}

.wrapper .form input {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	margin-bottom: 10px;
	margin-top: 20px;
}

.wrapper .form textarea {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	resize: none;
}

.wrapper .form .btn {
	background: #222222;
	color: white;
	font-size: 15px;
	border: none;
	outline: none;
	cursor: pointer;
	padding: 10px;
	width: 100%;
	border-radius: 20px;
	margin: 0 auto;
	display: block;
	margin-top: 5px;
	margin-bottom: 20px;
	opacity: 0.8;
	transition: 0.3s all ease;
}

.wrapper .form .btn:hover {
	opacity: 1;
}

.content {
	text-align: center;
	background: darkgray;
	color: black;
	padding: 10px;
	width: 750px;
	border-radius: 10px;
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.content p {
	margin-bottom: 15px;
	width: 450px;
}

.chatbutton {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:hover {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:focus {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:active {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chat {
  overflow: hidden;
  position: fixed;
  width: 100%;
  margin-top: 15px;
}
</style>
<button class="chatbutton" onclick="sexyteam()"><img src="https://i.postimg.cc/FHdctQSR/st1.jpg" width="50%" height="5%" style="border:solid 2px grey;border-radius: 40%;"></button>
<script>
function sexyteam() {
  var x = document.getElementById("sexyteamchat");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

<div id="sexyteamchat" class="container chat" style="display:none;">

<div class="wrapper">
    <center>
		<form action="" method="post" class="form">
		    <center>
			<input type="text" class="name" name="name" placeholder="Name">
			<br>
			<textarea name="message" cols="30" rows="10" class="message" placeholder="Message"></textarea>
			<br>
			<button type="submit" class="btn" name="post_comment">Send Message</button>
			</center>
		</form>
		<button class="btn" onclick="sexyteam()">Close Chat</button>
	</center>
</div>

<style>
div.scroll {
  width: 30%;
  height: 200px;
  overflow-x: hidden;
  overflow-y: auto;
  text-align: center;
  padding: 20px;
}
</style>

<div class="content scroll"> 

  <?php
   $sql_comment2 = "SELECT * FROM comments";
   $result_comments2 = mysqli_query($con, $sql_comment2);
   $queryResults2 = mysqli_num_rows($result_comments2);

   if ($queryResults2 > 0)
   {
    while ($row = mysqli_fetch_assoc($result_comments2))
    {
      echo "<div class='article-box' style='text-align: left;'>
      <h3><img src='https://i.postimg.cc/T15GdQJr/PFP.png' alt='SSS-Profile-Pictures' border='0' width='75' height='40'>".$row['name']."</h3>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['message']."</p>
      </div>";
    }
   }
  ?>
</div>

</div>	

</div>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->


<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>




<body bgcolor="white">
<style>
body {
  font-family: Arial, sans-serif;
}
</style>
<center>
<br>
<br>
<br>
<br>
<style>
.article-container {
    background-color: black;
    color: white;
    padding: 30px;
}

.article-box {
    padding-bottom: 30px;
    width: 100%;
}
</style>
<script id="wpcp_disable_selection" type="text/javascript">
//<![CDATA[
var image_save_msg='You Can Not Save images!';
var no_menu_msg='Context Menu disabled!';
var smessage = "Content is protected !!";
function disableEnterKey(e)
{
  if (e.ctrlKey){
     var key;
     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox (97)
    //if (key != 17) alert(key);
     if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
     {
          show_wpcp_message('You are not allowed to copy content or view source');
          return false;
     }else
       return true;
     }
}
function disable_copy(e)
{  
  var elemtype = e.target.nodeName;
  var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
  elemtype = elemtype.toUpperCase();
  var checker_IMG = '';
  if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    if (smessage !== "" && e.detail == 2)
      show_wpcp_message(smessage);
    
    if (isSafari)
      return true;
    else
      return false;
  }  
}
function disable_copy_ie()
{
  var elemtype = window.event.srcElement.nodeName;
  elemtype = elemtype.toUpperCase();
  if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    //alert(navigator.userAgent.indexOf('MSIE'));
      //if (smessage !== "") show_wpcp_message(smessage);
    return false;
  }
}  
function reEnable()
{
  return true;
}
document.onkeydown = disableEnterKey;
document.onselectstart = disable_copy_ie;
if(navigator.userAgent.indexOf('MSIE')==-1)
{
  document.onmousedown = disable_copy;
  document.onclick = reEnable;
}
function disableSelection(target)
{
    //For IE This code will work
    if (typeof target.onselectstart!="undefined")
    target.onselectstart = disable_copy_ie;
    
    //For Firefox This code will work
    else if (typeof target.style.MozUserSelect!="undefined")
    {target.style.MozUserSelect="none";}
    
    //All other  (ie: Opera) This code will work
    else
    target.onmousedown=function(){return false}
    target.style.cursor = "default";
}
//Calling the JS function directly just after body load
window.onload = function(){disableSelection(document.body);};
//]]>
</script>
<script id="wpcp_disable_Right_Click" type="text/javascript">
  //<![CDATA[
  document.ondragstart = function() { return false;}
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  Disable context menu on images by GreenLava Version 1.0
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
      function nocontext(e) {
         return false;
      }
      document.oncontextmenu = nocontext;
  //]]>
</script>
<style>
.unselectable
{
-moz-user-select:none;
-webkit-user-select:none;
cursor: default;
}
html
{
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
}
</style>
<script id="wpcp_css_disable_selection" type="text/javascript">
var e = document.getElementsByTagName('body')[0];
if(e)
{
  e.setAttribute('unselectable',on);
}
</script>
<script type="text/javascript">
    window.onbeforeunload = function() {
        return "Are you sure you want to leave?";
    }
</script>
<script language="JavaScript">
/*function check(e)
{
alert(e.keyCode);
}*/
document.addEventListener('contextmenu', event => event.preventDefault());

document.onkeydown = function (e) {
      
      if(e.keyCode == 123) {
          alert("F12 disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 67) {
          alert("ctrl + c disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 85) {
          alert("ctrl + u disable");
          return false;
      }
      
}     
</script>
<style>
.loader {
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loader > img {
    width: 100px;
}

.loader.hidden {
    animation: fadeOut 1s;
    animation-fill-mode: forwards;
}

@keyframes fadeOut {
    100% {
        opacity: 0;
        visibility: hidden;
    }
}

.thumb {
    height: 100px;
    border: 1px solid black;
    margin: 10px;
}
</style>
<script>
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");
    loader.className += " hidden"; // class "loader hidden"
});
</script>
<div class="loader">
<img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." /></div>










<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #181818;
  opacity: 0.90;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #F0F0F0;
}
.fixed-nav-bar { position: fixed; top: 0; left: 0; z-index: 9999; width: 100%; height: 50px; background-color: ##333; }
</style>
<nav  class="fixed-nav-bar">
<ul>
 <li><a class="" href="start.html"><i class="fa fa-fw fa-home"></i>&nbsp;<?php echo $lang['home'] ?></a></li>
 <li><a class="" href="index.php"><i class="fa-solid fa-circle-info"></i>&nbsp;<?php echo $lang['about'] ?></a></li>
 <li><a class="" href="web.php"><i class="fa-sharp fa-solid fa-network-wired"></i></i></i>&nbsp;<?php echo $lang['web'] ?></a></li>
 <?php if ( $user_data['type'] === 'Test') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='owner.php'><i class='fa-solid fa-unlock'></i>&nbsp;".$lang['owner']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <li><a class="" href="profile.php"><img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="32" height="16"><?php echo $user_data['user_name']; ?></a></a></li>
 
  <?php
   $query = "select * from news";
   $query_run = mysqli_query($con, $query);
   $row = mysqli_num_rows($query_run);
  ?>
 <style>
  #count {
    border-radius: 50%;
    position: relative;
    top: -10px;
    left: -10px;
  }
 </style>
  <style>
      span.circle {
        background: #e3e3e3;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        color: #6e6e6e;
        display: inline-block;
        font-weight: bold;
        line-height: 18px;
        margin-right: 5px;
        text-align: center;
        width: 18px;
      }
</style>
 <li><a class="" href="read-news.php"><i class="fa-solid fa-bell"></i>&nbsp;<span class="circle" id="count"><?php echo $row ?></span></a></li>
  <style>
   li:last-child {
        float: right; /* last li item */
        top:10px;
    }
 </style>
  <li><a href="ssc.php"><img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?php echo $user_data['ssc']; ?></a></li>
</ul>
</nav>









<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>






<div style="background-color:black;">
<br>
<a href="rss.xml"><i class="fa-sharp fa-solid fa-square-rss fa-lg"></i></a>
<select style="color:black;" onchange="location = this.value;">
 <option></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=en"><?php echo $lang['english'] ?></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=ar"><?php echo $lang['arabic'] ?></option>
</select>
<br><br>
</div>



<style>
    @media (max-width: 767px) {
        .hidden-mobile {
          display: none;
        }
    }
</style>
<style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #E8E8E8;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #F0F0F0;
}
</style>
<button onclick="topFunction()" id="myBtn" title="Go to top">  ^  </button>
<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
<br>
<br>
<br>

<style>
img.rounded-corners {
  border-radius: 15px;
}
</style>


<link rel="stylesheet"
      href="//cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.7.0/build/styles/default.min.css">
<script src="//cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.7.0/build/highlight.min.js"></script>
<script>
hljs.initHighlightingOnLoad();

const highlights = document.querySelectorAll("div.highlight")

</script>

<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/highlight.js@11.7.0/styles/codepen-embed.css">
</head>


<body>

<center>
<div class="hidden-mobile">
<a href="worlds.php"><img src="https://i.postimg.cc/MGHLq5hs/s-s-scriptties-ad.jpg" class="rounded-corners" alt="S.S.S WORLDS AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p1" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://ssscriptties.000webhostapp.com/worlds.php"&gt;&lt;img src="https://i.postimg.cc/MGHLq5hs/s-s-scriptties-ad.jpg" class="rounded-corners" alt="S.S.S WORLDS AD" width="400" 
height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p1')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="https://scriptties.gitlab.io/sss-elections/"><img src="https://i.postimg.cc/3whwqyVJ/s-s-scriptties-ad2.jpg" class="rounded-corners" alt="S.S.S ELECTION AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p2" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://scriptties.gitlab.io/sss-elections/"&gt;&lt;img src="https://i.postimg.cc/3whwqyVJ/s-s-scriptties-ad2.jpg" class="rounded-corners" alt="S.S.S ELECTION AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p2')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="https://ssscriptties.itch.io/today"><img src="https://i.postimg.cc/rz6Tt3LF/s-s-scriptties-ad3.jpg" class="rounded-corners" alt="S.S.S TODAY AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p3" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://ssscriptties.itch.io/today"&gt;&lt;img src="https://i.postimg.cc/rz6Tt3LF/s-s-scriptties-ad3.jpg" class="rounded-corners" alt="S.S.S TODAY AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p3')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="https://ssscriptties-mods.itch.io/one-night-at-sexy-sellouts"><img src="https://i.postimg.cc/nhhsV9TR/s-s-scriptties-ad4.jpg" class="rounded-corners" alt="S.S.S FNAF FG AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p4" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://ssscriptties-mods.itch.io/one-night-at-sexy-sellouts"&gt;&lt;img src="https://i.postimg.cc/nhhsV9TR/s-s-scriptties-ad4.jpg" class="rounded-corners" alt="S.S.S FNAF FG AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p4')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="https://ssscriptties-mods.itch.io/sss-coding-minecraft-1165-forge-mode"><img src="https://i.postimg.cc/jS8mJBT6/s-s-scriptties-ad5.jpg" class="rounded-corners" alt="S.S.S MC AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p5" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://ssscriptties-mods.itch.io/sss-coding-minecraft-1165-forge-mode"&gt;&lt;img src="https://i.postimg.cc/jS8mJBT6/s-s-scriptties-ad5.jpg" class="rounded-corners" alt="S.S.S MC AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p5')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="library.php"><img src="https://i.postimg.cc/RFGXjH07/s-s-scriptties-ad6.jpg" class="rounded-corners" alt="S.S.S BOOKS AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p6" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://ssscriptties.000webhostapp.com/library.php"&gt;&lt;img src="https://i.postimg.cc/RFGXjH07/s-s-scriptties-ad6.jpg" class="rounded-corners" alt="S.S.S BOOKS AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p6')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center><br><br>

<center>
<div class="hidden-mobile">
<a href="https://scriptties.github.io/admin-room/"><img src="https://i.postimg.cc/fL6vdnBP/s-s-scriptties-ad7.jpg" class="rounded-corners" alt="S.S.S ADMIN AD" width="400" 
     height="100" border="2px solid #FFFFFF"></a>
</div>
     <br>
</center><br><br>

<center>
<div style="background-color:black;">
<br><br>
<pre style="width: 450px;">
<code id="p7" class="language-html" style="text-align: left; width: 800px;">
&lt;style&gt;
img.rounded-corners {
   border-radius: 15px;
}
&lt;/style&gt;
&lt;a href="https://scriptties.github.io/admin-room/"&gt;&lt;img src="https://i.postimg.cc/fL6vdnBP/s-s-scriptties-ad7.jpg" class="rounded-corners" alt="S.S.S ADMIN AD" width="400" 
     height="100" border="2px solid #FFFFFF"&gt;&lt;/a&gt;
</code>
<br><button onclick="copyToClipboard('#p7')"><?php echo $lang['copy2'] ?></button>
</pre>
<br><br>
</div>
</center>

<center>
<img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" border="0">
</center>
<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</body>
</html>
