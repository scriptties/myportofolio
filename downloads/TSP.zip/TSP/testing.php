<?php 

error_reporting(0);

session_start();

	include("connection.php");
	include("functions.php");
	include("config.php");


	$user_data = check_login($con);
	$user_data = check_key($con);
	

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>

<div class="MagicScroll headline" data-options="items: 1; autoplay: 3000; width: 400; height: 60; arrows: off;">
    <span><a href="/buy/magic360/"><b>Magic 360</b></a> - spin products 360 degrees.</span>
    <span><a href="/buy/magiczoomplus/"><b>Magic Zoom Plus</b></a> - hover to zoom, click for expanded view.</span>
    <span><a href="/buy/magicscroll/"><b>Magic Scroll</b></a> - effortlessly scroll through products.</span>
    <span><a href="/buy/magiczoom/"><b>Magic Zoom</b></a> - hover to zoom into your images.</span>
    <span><a href="/buy/magicslideshow/"><b>Magic Slideshow</b></a> - watch a whole series of images.</span>
    <span><a href="/buy/magicthumb/"><b>Magic Thumb</b></a> - enlarge your images to full-screen.</span>
</div>

