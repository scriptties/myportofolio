<?php
// This code will block any IP address that makes more than 10 requests in a 10-second period.

$uri = md5($_SERVER['REQUEST_URI']);
$exp = 10; // 10 seconds
$hash = $uri . '|'. time();

if (! isset($_SESSION['ddos'])) {
  $_SESSION['ddos'] = $hash;
} else {
  list($_uri, $_exp) = explode('|', $_SESSION['ddos']);
  if ($_uri == $uri && time() - $_exp < $exp) {
    header('HTTP/1.1 503 Service Unavailable');
    die('Too many requests.');
  }
}

?>
