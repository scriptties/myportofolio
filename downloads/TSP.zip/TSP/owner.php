<?php 
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);
	$user_data = check_key($con);

    If ( $user_data['type'] != 'Head-Admin'){ 
        echo "<html><br><br><br><br><br><center><h1>you do not have access to this section</h1></center>
        <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'></html>"; 
        exit; 
        } 

?>


<html>
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">


<style>
html {
  font-size: 15px;
}
</style>

    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>

<head>
    
    
<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>
    
    
    
    
<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>

<title>Owner | S.S.S</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>

  

<style>
body {
  font-family: Arial, sans-serif;
}
</style>

<style>
 a.button3{
 display:inline-block;
 padding:0.3em 1.2em;
 margin:0 0.3em 0.3em 0;
 border-radius:2em;
 box-sizing: border-box;
 text-decoration:none;
 font-family:'Roboto',sans-serif;
 font-weight:300;
 color:#E8E8E8;
 background-color:black;
 text-align:center;
 transition: all 0.2s;
}
a.button3:hover{
 background-color:#F0F0F0;
}
@media all and (max-width:30em){
 a.button3{
  display:block;
  margin:0.2em auto;
 }
}
</style>

<style>
input {
    padding: 0px 20px;
    width: 300px;
    height: 40px;
    font-size: 22px;
    color: black;
}
</style>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<?php
if (isset($_POST['post_comment'])) {

    $name = $_POST['name'];
    $message = $_POST['message'];
    
    $sql = "INSERT INTO comments (name, message)
    VALUES ('$name', '$message')";

    if ($con->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error: " . $sql . "<br>" . $con->$error;
    }
}
?>
<br>

<style>

* { margin: 0; padding: 0; box-sizing: border-box; }



.wrapper {
	background: white;
	border-radius: 10px;
	width: 30%;
	height: auto;
	display: flex;
	justify-content: center;
	align-items: center;
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	border:solid 3px grey;
}

.wrapper .form input {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	margin-bottom: 10px;
	margin-top: 20px;
}

.wrapper .form textarea {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	resize: none;
}

.wrapper .form .btn {
	background: #222222;
	color: white;
	font-size: 15px;
	border: none;
	outline: none;
	cursor: pointer;
	padding: 10px;
	width: 100%;
	border-radius: 20px;
	margin: 0 auto;
	display: block;
	margin-top: 5px;
	margin-bottom: 20px;
	opacity: 0.8;
	transition: 0.3s all ease;
}

.wrapper .form .btn:hover {
	opacity: 1;
}

.content {
	text-align: center;
	background: darkgray;
	color: black;
	padding: 10px;
	width: 750px;
	border-radius: 10px;
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.content p {
	margin-bottom: 15px;
	width: 450px;
}

.chatbutton {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:hover {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:focus {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:active {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chat {
  overflow: hidden;
  position: fixed;
  width: 100%;
  margin-top: 15px;
}
</style>
<button class="chatbutton" onclick="sexyteam()"><img src="https://i.postimg.cc/FHdctQSR/st1.jpg" width="50%" height="5%" style="border:solid 2px grey;border-radius: 40%;"></button>
<script>
function sexyteam() {
  var x = document.getElementById("sexyteamchat");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

<div id="sexyteamchat" class="container chat" style="display:none;">

<div class="wrapper">
    <center>
		<form action="" method="post" class="form">
		    <center>
			<input type="text" class="name" name="name" placeholder="Name">
			<br>
			<textarea name="message" cols="30" rows="10" class="message" placeholder="Message"></textarea>
			<br>
			<button type="submit" class="btn" name="post_comment">Send Message</button>
			</center>
		</form>
		<button class="btn" onclick="sexyteam()">Close Chat</button>
	</center>
</div>

<style>
div.scroll {
  width: 30%;
  height: 200px;
  overflow-x: hidden;
  overflow-y: auto;
  text-align: center;
  padding: 20px;
}
</style>

<div class="content scroll"> 

  <?php
   $sql_comment2 = "SELECT * FROM comments";
   $result_comments2 = mysqli_query($con, $sql_comment2);
   $queryResults2 = mysqli_num_rows($result_comments2);

   if ($queryResults2 > 0)
   {
    while ($row = mysqli_fetch_assoc($result_comments2))
    {
      echo "<div class='article-box' style='text-align: left;'>
      <h3><img src='https://i.postimg.cc/T15GdQJr/PFP.png' alt='SSS-Profile-Pictures' border='0' width='75' height='40'>".$row['name']."</h3>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['message']."</p>
      </div>";
    }
   }
  ?>
</div>

</div>	

</div>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->


</head>

<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>







<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #181818;
  opacity: 0.90;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #F0F0F0;
}
.fixed-nav-bar { position: fixed; top: 0; left: 0; z-index: 9999; width: 100%; height: 50px; background-color: ##333; }
</style>
<nav  class="fixed-nav-bar">
<ul>
 <li><a class="" href="start.html"><i class="fa fa-fw fa-home"></i>&nbsp;Home</a></li>
 <li><a class="" href="index.php"><i class="fa-solid fa-circle-info"></i>&nbsp;About</a></li>
 <li><a class="" href="web.php"><i class="fa-sharp fa-solid fa-network-wired"></i></i></i>&nbsp;Web</a></li>
 <?php if ( $user_data['type'] === 'Test') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;Testing</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;Admin</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;Testing</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;Admin</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;Testing</a></li>";
 } ?>
 <li><a class="" href="profile.php"><img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="32" height="16"><?php echo $user_data['user_name']; ?></a></a></li>
 
 
  <?php
   $query = "select * from news";
   $query_run = mysqli_query($con, $query);
   $row = mysqli_num_rows($query_run);
  ?>
 <style>
  #count {
    border-radius: 50%;
    position: relative;
    top: -10px;
    left: -10px;
  }
 </style>
  <style>
      span.circle {
        background: #e3e3e3;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        color: #6e6e6e;
        display: inline-block;
        font-weight: bold;
        line-height: 18px;
        margin-right: 5px;
        text-align: center;
        width: 18px;
      }
</style>
 <li><a class="" href="read-news.php"><i class="fa-solid fa-bell"></i>&nbsp;<span class="circle" id="count"><?php echo $row ?></span></a></li>
  <style>
   li:last-child {
        float: right; /* last li item */
        top:10px;
    }
 </style>
  <li><a href="ssc.php"><img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?php echo $user_data['ssc']; ?></a></li>
</ul>
</nav>














<body>

<br><br><br><br><br>
<center>
<input type="file">

<br><br>

<p>S.S.S Files Which Contain S.S.S Plans, Backups, And Important Info.</p>
<a href="https://password.link/Npub0lX/#TTk9bFtLcG9PNUBYUEZnS1RX" class="button3"> S.S.S | Files </a>
<a href="https://www.mediafire.com/folder/y7gune5yjgg7b/Documents" class="button3"> S.S.S | Video Files </a>
<a href="https://strimm.com/Ssscriptties/my-studio/SSScriptties" class="button3"> S.S.S | Strimm </a>
</center>

<center>
<br><br><br>
<div><img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" alt="Powered-By-SSS-removebg-preview" border="0"></div>
</center>
<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</body>

</html>