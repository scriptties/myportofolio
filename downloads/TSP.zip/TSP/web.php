<?php
#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

session_start();

include("connection.php");
include("functions.php");
include("config.php");


$user_data = check_login($con);
$user_data = check_key($con);
error_reporting(0);

$Error = "";

if($_SERVER['REQUEST_METHOD'] == "POST")
{

  $a_title = mysqli_real_escape_string($con, $_POST['a_title']);
  if(!preg_match("/^[a-zA-Z0-9]+$/", $a_title))
  {
    $Error = "a title can can only include (a-z) (A-Z) (0-9)<br>";
  }
  $a_title = esc($_POST['a_title']);

  $a_text = mysqli_real_escape_string($con, $_POST['a_text']);
  $a_text = esc($_POST['a_text']);

  $a_author = mysqli_real_escape_string($con, $_POST['a_author']);
  if(!preg_match("/^[a-zA-Z0-9]+$/", $a_author))
  {
    $Error = "an author name can can only include (a-z) (A-Z) (0-9)<br>";
  }
  $a_author = esc($_POST['a_author']);

  $a_date = mysqli_real_escape_string($con, $_POST['a_date']);
  $a_date = esc($_POST['a_date']);



  $check_duplicate_link = "SELECT a_text FROM article WHERE a_text = '$a_text' ";
  $result = mysqli_query($con, $check_duplicate_link);
  $count = mysqli_num_rows($result);

  if($count > 0)
  {
    echo "<center><br><br><br><br><p style='color:white;'>link already taken</p></center>";
  }

  $check_duplicate_title = "SELECT a_title FROM article WHERE a_title = '$a_title' ";
  $result = mysqli_query($con, $check_duplicate_title);
  $count = mysqli_num_rows($result);

  if($count > 0)
  {
    echo "<center><br><br><br><br><p style='color:white;'>title already taken</p></center>";
  }


  if(!empty($a_title) && !empty($a_text) && !empty($a_author) && !empty($a_date) && !is_numeric($a_title) && $Error == "")
  {

    $query = "insert into article (a_title,a_text,a_author,a_date) values ('$a_title','$a_text','$a_author','$a_date')";


    mysqli_query($con, $query);

  }
  else
  {
    echo "<center><p style='color:white;'>oy, enter some valid information</p></center>";
  }

}


?>


<!DOCTYPE html>
<html lang="en-US">
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">



<style>
html {
  font-size: 15px;
}
</style>


    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>

<head>
   
<style>
html, body {
     width: 100%;
     min-height: 100%;
}

.a {
    width: 100%;
    height: auto;
}
</style>  
    
    
<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<?php
if (isset($_POST['post_comment'])) {

    $name = $_POST['name'];
    $message = $_POST['message'];
    
    $sql = "INSERT INTO comments (name, message)
    VALUES ('$name', '$message')";

    if ($con->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error: " . $sql . "<br>" . $con->$error;
    }
}
?>
<br>

<style>

* { margin: 0; padding: 0; box-sizing: border-box; }



.wrapper {
	background: white;
	border-radius: 10px;
	width: 30%;
	height: auto;
	display: flex;
	justify-content: center;
	align-items: center;
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	border:solid 3px grey;
}

.wrapper .form input {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	margin-bottom: 10px;
	margin-top: 20px;
}

.wrapper .form textarea {
	background: #222222;
	color: white;
	font-size: 15px;
	width: 100%;
	border-radius: 20px;
	padding: 10px;
	border: none;
	outline: none;
	resize: none;
}

.wrapper .form .btn {
	background: #222222;
	color: white;
	font-size: 15px;
	border: none;
	outline: none;
	cursor: pointer;
	padding: 10px;
	width: 100%;
	border-radius: 20px;
	margin: 0 auto;
	display: block;
	margin-top: 5px;
	margin-bottom: 20px;
	opacity: 0.8;
	transition: 0.3s all ease;
}

.wrapper .form .btn:hover {
	opacity: 1;
}

.content {
	text-align: center;
	background: darkgray;
	color: black;
	padding: 10px;
	width: 750px;
	border-radius: 10px;
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.content p {
	margin-bottom: 15px;
	width: 450px;
}

.chatbutton {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:hover {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:focus {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chatbutton:active {
  margin-top:555px;
  right:1200px;
  background-color: Transparent;
  background-repeat:no-repeat;
  border:none;
  cursor:pointer;
  overflow: hidden; 
  position: fixed;
}

.chat {
  overflow: hidden;
  position: fixed;
  width: 100%;
  margin-top: 15px;
}
</style>
<button class="chatbutton" onclick="sexyteam()"><img src="https://i.postimg.cc/FHdctQSR/st1.jpg" width="50%" height="5%" style="border:solid 2px grey;border-radius: 40%;"></button>
<script>
function sexyteam() {
  var x = document.getElementById("sexyteamchat");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

<div id="sexyteamchat" class="container chat" style="display:none;">

<div class="wrapper">
    <center>
		<form action="" method="post" class="form">
		    <center>
			<input type="text" class="name" name="name" placeholder="Name">
			<br>
			<textarea name="message" cols="30" rows="10" class="message" placeholder="Message"></textarea>
			<br>
			<button type="submit" class="btn" name="post_comment">Send Message</button>
			</center>
		</form>
		<button class="btn" onclick="sexyteam()">Close Chat</button>
	</center>
</div>

<style>
div.scroll {
  width: 30%;
  height: 200px;
  overflow-x: hidden;
  overflow-y: auto;
  text-align: center;
  padding: 20px;
}
</style>

<div class="content scroll"> 

  <?php
   $sql_comment2 = "SELECT * FROM comments";
   $result_comments2 = mysqli_query($con, $sql_comment2);
   $queryResults2 = mysqli_num_rows($result_comments2);

   if ($queryResults2 > 0)
   {
    while ($row = mysqli_fetch_assoc($result_comments2))
    {
      echo "<div class='article-box' style='text-align: left;'>
      <h3><img src='https://i.postimg.cc/T15GdQJr/PFP.png' alt='SSS-Profile-Pictures' border='0' width='75' height='40'>".$row['name']."</h3>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['message']."</p>
      </div>";
    }
   }
  ?>
</div>

</div>	

</div>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>
<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>




<script id="wpcp_disable_selection" type="text/javascript">
//<![CDATA[
var image_save_msg='You Can Not Save images!';
var no_menu_msg='Context Menu disabled!';
var smessage = "Content is protected !!";
function disableEnterKey(e)
{
  if (e.ctrlKey){
     var key;
     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox (97)
    //if (key != 17) alert(key);
     if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
     {
          show_wpcp_message('You are not allowed to copy content or view source');
          return false;
     }else
       return true;
     }
}
function disable_copy(e)
{  
  var elemtype = e.target.nodeName;
  var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
  elemtype = elemtype.toUpperCase();
  var checker_IMG = '';
  if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    if (smessage !== "" && e.detail == 2)
      show_wpcp_message(smessage);
    
    if (isSafari)
      return true;
    else
      return false;
  }  
}
function disable_copy_ie()
{
  var elemtype = window.event.srcElement.nodeName;
  elemtype = elemtype.toUpperCase();
  if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    //alert(navigator.userAgent.indexOf('MSIE'));
      //if (smessage !== "") show_wpcp_message(smessage);
    return false;
  }
}  
function reEnable()
{
  return true;
}
document.onkeydown = disableEnterKey;
document.onselectstart = disable_copy_ie;
if(navigator.userAgent.indexOf('MSIE')==-1)
{
  document.onmousedown = disable_copy;
  document.onclick = reEnable;
}
function disableSelection(target)
{
    //For IE This code will work
    if (typeof target.onselectstart!="undefined")
    target.onselectstart = disable_copy_ie;
    
    //For Firefox This code will work
    else if (typeof target.style.MozUserSelect!="undefined")
    {target.style.MozUserSelect="none";}
    
    //All other  (ie: Opera) This code will work
    else
    target.onmousedown=function(){return false}
    target.style.cursor = "default";
}
//Calling the JS function directly just after body load
window.onload = function(){disableSelection(document.body);};
//]]>
</script>
<script id="wpcp_disable_Right_Click" type="text/javascript">
  //<![CDATA[
  document.ondragstart = function() { return false;}
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  Disable context menu on images by GreenLava Version 1.0
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
      function nocontext(e) {
         return false;
      }
      document.oncontextmenu = nocontext;
  //]]>
</script>
<style>
.unselectable
{
-moz-user-select:none;
-webkit-user-select:none;
cursor: default;
}
html
{
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
}
</style>
<script id="wpcp_css_disable_selection" type="text/javascript">
var e = document.getElementsByTagName('body')[0];
if(e)
{
  e.setAttribute('unselectable',on);
}
</script>
<script type="text/javascript">
    window.onbeforeunload = function() {
        return "Are you sure you want to leave?";
    }
</script>
<div class="loader">
    <img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." />
</div>
<script language="JavaScript">
/*function check(e)
{
alert(e.keyCode);
}*/
document.addEventListener('contextmenu', event => event.preventDefault());

document.onkeydown = function (e) {
      
      if(e.keyCode == 123) {
          alert("F12 disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 67) {
          alert("ctrl + c disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 85) {
          alert("ctrl + u disable");
          return false;
      }
      
}     
</script>
<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #181818;
  opacity: 0.90;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #F0F0F0;
}
.fixed-nav-bar { position: fixed; top: 0; left: 0; z-index: 9999; width: 100%; height: 50px; background-color: ##333; }
</style>

<nav  class="fixed-nav-bar">
<ul>
 <li><a class="" href="start.html"><i class="fa fa-fw fa-home"></i>&nbsp;<?php echo $lang['home'] ?></a></li>
 <li><a class="" href="index.php"><i class="fa-solid fa-circle-info"></i>&nbsp;<?php echo $lang['about'] ?></a></li>
 <?php if ( $user_data['type'] === 'Test') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='owner.php'><i class='fa-solid fa-unlock'></i>&nbsp;".$lang['owner']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <li><a class="" href="profile.php"><img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="32" height="16"><?php echo $user_data['user_name']; ?></a></a></li>
 
  <?php
   $query = "select * from news";
   $query_run = mysqli_query($con, $query);
   $row = mysqli_num_rows($query_run);
  ?>
 <style>
  #count {
    border-radius: 50%;
    position: relative;
    top: -10px;
    left: -10px;
  }
 </style>
  <style>
      span.circle {
        background: #e3e3e3;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        color: #6e6e6e;
        display: inline-block;
        font-weight: bold;
        line-height: 18px;
        margin-right: 5px;
        text-align: center;
        width: 18px;
      }
</style>
 <li><a class="" href="read-news.php"><i class="fa-solid fa-bell"></i>&nbsp;<span class="circle" id="count"><?php echo $row ?></span></a></li>
  <style>
   li:last-child {
        float: right; /* last li item */
        top:10px;
    }
 </style>
  <li><a href="ssc.php"><img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?php echo $user_data['ssc']; ?></a></li>
</ul>
</nav>
</div>

<style>
 a.button3{
 display:inline-block;
 padding:0.3em 1.2em;
 margin:0 0.3em 0.3em 0;
 border-radius:2em;
 box-sizing: border-box;
 text-decoration:none;
 font-family:'Roboto',sans-serif;
 font-weight:300;
 color:#E8E8E8;
 background-color:black;
 text-align:center;
 transition: all 0.2s;
 width: 30%;
 height: auto;
}
a.button3:hover{
 background-color:#F0F0F0;
}
@media all and (max-width:30em){
 a.button3{
  display:block;
  margin:0.2em auto;
 }
}

.down {
 width: 18%;
 height: auto;
}
</style>
<style>
.loader {
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loader > img {
    width: 100px;
}

.loader.hidden {
    animation: fadeOut 1s;
    animation-fill-mode: forwards;
}

@keyframes fadeOut {
    100% {
        opacity: 0;
        visibility: hidden;
    }
}

.thumb {
    height: 100px;
    border: 1px solid black;
    margin: 10px;
}
</style>
<script>
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");
    loader.className += " hidden"; // class "loader hidden"
});
</script>
<style>
body {
  font-family: Arial;
}

* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
</style>





<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>






    <style>
      body {
        background: black;
      }
    </style>

<style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #E8E8E8;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #F0F0F0;
}
</style>
<button onclick="topFunction()" id="myBtn" title="Go to top">  ^  </button>
<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
<br>
<br>
<br>
<br>
<center>

</center>
<br>
<br>
<br>
<br>
<br>

<center>
<div class="fade-in-element">
<img width="70%" height="auto" src="https://i.postimg.cc/wB007dfz/soosle.png" alt="soosle" border="0">
</div>

<center>

<br>
<br>
<style>
.article-container {
    background-color: white;
    color: black;
    padding: 30px;
}

.article-box {
    padding-bottom: 30px;
    width: 100%;
}

input {
    padding: 0px 20px;
    width: 300px;
    height: 40px;
    font-size: 22px;
    color: black;
}

.search-button  {
  width: 65px;
  height: 40px;
  font-size: 22px;
}

</style>

<script src="https://code.jquery.com/jquery-3.4.1.min.js" 
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" 
        crossorigin="anonymous">
</script>
<style>
input[type="search"] {
    width: 350px;
    height: 45px;
    padding-right: 50px;
    border: 1px solid white;
    box-sizing: border-box;
    border: 3px solid white;
    -webkit-transition: 0.5s;
    transition: 0.5s;
    outline: none;
}

input[type="search"]:focus {
  border: 3px solid white;
}

#buttonS {
    margin-left: -50px;
    height: 45px;
    width: 70px;
    border-radius: 40px;
    border: 6px solid white;
}
</style>


<div class="fade-in-element">
<center>
<form action="search.php" method="POST">

  <input type="search" name="search" placeholder="<?php echo $lang['search'] ?>">
  <button id="buttonS" class="search-button" type="submit" name="submit-search"><i class="fa-solid fa-magnifying-glass"></i></button>
</form>
<br>
<a href="rss.xml"><i class="fa-sharp fa-solid fa-square-rss fa-lg"></i></a>
<select style="color:black;" onchange="location = this.value;">
 <option></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=en"><?php echo $lang['english'] ?></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=ar"><?php echo $lang['arabic'] ?></option>
</select>
<br>
</div>


<SCRIPT>
function ShowAndHide() {
    var x = document.getElementById('SectionName');
    if (x.style.display == 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</SCRIPT>

<br><br><br><br><br><br>
<div class="fade-in-element">
<button onclick="copyToClipboard('#p1')"> <?php echo $lang['pgpc'] ?> </button>
<BUTTON ONCLICK="ShowAndHide2()"> <?php echo $lang['pgpr'] ?> </BUTTON>
<BUTTON ONCLICK="ShowAndHide()"><?php echo $lang['site'] ?></BUTTON>
<BUTTON ONCLICK=""><?php echo $lang['terms'] ?></BUTTON>
<BUTTON ONCLICK=""><?php echo $lang['pages'] ?></BUTTON>
</div>
<DIV ID="SectionName" STYLE="display:none">
<form method="post">
<div class="article-container">
<div class="fade-in-element">
<div class="alert alert-warning alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Warning!</strong><?php echo $lang['warning'] ?>
</div>
</div>	
<br>
<br>
<div>
<?php
if (isset($Error) && $Error != "") {
  echo $Error;
}
?>
</div>

			<input type="text" name="a_title" placeholder="Title"><br><br>
			<input type="url" name="a_text" placeholder="URL"><br><br>
      <input type="text" name="a_author" placeholder="Author Name"><br><br>

			<input id="button" type="submit" value="Submit"><br><br>
</div>
</form>

  <?php
   $sql = "SELECT * FROM article";
   $a_result = mysqli_query($con, $sql);
   $queryResults = mysqli_num_rows($a_result);

   if ($queryResults > 0)
   {
    while ($row = mysqli_fetch_assoc($a_result))
    {
      echo "<div class='article-box'>
      <h3>".$row['a_title']."</h3>
      <p><a href=".$row['a_text'].">".$row['a_text']."</a></p>
      <p>".$row['a_date']."</p>
      <p><img src='/images/PFP.png' alt='SSS-Profile-Pictures' border='0' width='75' height='40'>".$row['a_author']."</p>
      </div>";
    }
   }
  ?>
</div>
</DIV>
<style>
button {
    background-color: lightgrey;
    border-radius: 10px;
}
button:hover {
    background-color: darkgrey;
}
button:active {
    background-color: grey;
}
input {
    border-radius: 20px;
}
</style>

<div style="background-color:white;color:white;padding:30px">
<div class="fade-in-element">
<p id="p1" style="background-color: #F0F0F0; color:black; border-radius: 20px;">
-----BEGIN PGP MESSAGE-----

hF4DgztFgdbJf70SAQdA1iHJVOwW6KhC0rWkurx09NReXmYgOkGXfKUOfh+84UAw
TlOpUJitXpK4R+gP6V9/2stHtEEZXjbNm4idc3GQ7ft4emehusv75X1USqwXxY0A
1MBkAQkCENbjUrJYm7HpV6skbc/jfhxs9w/bLGq1I6orr1N1Dw85rKjNo1pGULU7
p0iZ4nXJ3Y8SzjSfdVkKjVvJWSwO5G49CsZgWagV4OBVMgbrXubc3Q6LuEHDOcF+
iIGPds5cVbgP8vvWvHv35mhDn7hiwgETfHI33/Swa/VCKVZzykHTnJHqhHo2dIkz
GgKVwvy/60sOdkOCzT6Ae3Fh9KOnBOl54pxludUV6Nagv2Hg3cobbNAR55g4smHC
5vF3hfTKJ1nK0V1cIBuX6PGCulGW9Icd9qaxoK2XXnv4PcNqENjnkYxkRJzL4dPz
6mSz0ESXiagJ6v0m7yZJiQjK+8yWg0HOuAZDHF2oZ0WewQJJWBLLkRKCUZSN3c9U
YG9vnPNrtQ==
=S9+t
-----END PGP MESSAGE-----
</p>
</div>
<br>


<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>


<SCRIPT>
function ShowAndHide2() {
    var x = document.getElementById('SectionName2');
    if (x.style.display == 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</SCRIPT>
<DIV ID="SectionName2" STYLE="display:none">
<br>
<p style="background-color: #F0F0F0; color: black;">
Contact "<b>scriptties@gtfcy37qyzor7kb6blz2buwuu5u7qjkycasjdf3yaslibkbyhsxub4yd.onion</b>" or chat in the "<b>Sexy.Support.Team</b>" chat.
</p>
</DIV>
</div>
<br>

<center>


<style>
img.rounded-corners {
  border-radius: 15px;
}
</style>
<br>



<center>
  <br>
  <br>
  <br>
<div style="background-color:white;color:white;padding:30px">
<a href="https://s-s-scr.myshopify.com/" class="hidden-xs"><img src="https://i.postimg.cc/DfJ3kC00/ad8.jpg" class="rounded-corners" alt="S.S.S Merch AD" width="400" height="100" border="2px solid #FFFFFF" class="hidden-xs"></a>
<center>





<title>
web | S.S.S
</title>


</head>

<body bgcolor="black" style="color:white;font;family:courier">

<br>
<br>
<br>
<br>
<br>
<br>
<br>

<center>
<a href="filesharing.php" class="button3"> <img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"> SFS | S.S.S </a>

<a href="https://scriptties.gitlab.io/sss/" class="button3"> S4&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="deepweb.php" class="button3"> SDW | S.S.S </a>

<a href="library.php" class="button3"> SBL&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S  </a>

<a href="memes.php" class="button3"> SRM | S.S.S </a>

<a href="minecraft.php" class="button3"> <img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"> SMC | S.S.S </a>

<a href="partners.php" class="button3"> SKP | S.S.S </a>

<a href="law.php" class="button3"> SBI | S.S.S </a>

<a href="language.php" class="button3"> SCL | S.S.S </a>

<a href="videos.php" class="button3"> SKV | S.S.S </a>

<a href="worlds.php" class="button3"> <img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"> SGW&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="ads.php" class="button3"> SAD | S.S.S </a>

<a href="https://strimm.com/Ssscriptties/SSScriptties" class="button3"> STV&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="sport.php" class="button3"> SYS | S.S.S </a>

<a href="chat.php" class="button3"> STC | S.S.S </a>

<center>

<br>

<center>
<a href="https://www.mediafire.com/folder/dsncrj1p4qvki/S.S.S_anomalies" class="button3"> SDA&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="crypto.php" class="button3"> SSC&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="https://clubcreator.com/team/sss#profile" class="button3"> SKC&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S </a>

<a href="projects.php" class="button3"> SSP | S.S.S </a>

<a href="operations.php" class="button3"> SOP | S.S.S </a>

<a href="piratedcontent.php" class="button3"> <img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"> SPC | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>
<center>

<br>

<center>
<a href="" class="button3"> CS | S.S.S </a>
 
<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>

<a href="" class="button3"> CS | S.S.S </a>
<center>

<br>
<br>
<br>

<center>
    
<div class="down">

<a href="index.php" class="button3"> < </a>
  
<a href="" class="button3"> <i class="fa-sharp fa-solid fa-rotate-right"></i> </a>

<a href="hacking.php" class="button3"> > </a>

<br>

<a href="start.html" class="button3"> << </a>

<a href="tspm.php" class="button3"> >> </a>

</div>
<br>
<br>

<center><img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" alt="Powered-By-SSS-removebg-preview" border="0"></center>

</div>
<center>

 </body>

<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</html>
