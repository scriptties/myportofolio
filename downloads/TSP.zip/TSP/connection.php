<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "m22112405";
$dbname = "db_tps";

if(!$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname))
{
    die("failed to connect");
}

?>