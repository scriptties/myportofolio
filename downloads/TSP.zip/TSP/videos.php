<?php
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

session_start();

include("connection.php");
include("functions.php");
include("config.php");


$user_data = check_login($con);
$user_data = check_key($con);


?>


<html>
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">



<style>
html {
  font-size: 15px;
}
</style>

    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>
    
<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>
    
<title>Videos | S.S.S</title>

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>

<body bgcolor="white">
<style>
body {
  font-family: Arial, sans-serif;
}
</style>
<center>
<br>
<br>
<br>
<br>
<style>
.article-container {
    background-color: black;
    color: white;
    padding: 30px;
}
</style>
<script id="wpcp_disable_selection" type="text/javascript">
//<![CDATA[
var image_save_msg='You Can Not Save images!';
var no_menu_msg='Context Menu disabled!';
var smessage = "Content is protected !!";
function disableEnterKey(e)
{
  if (e.ctrlKey){
     var key;
     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox (97)
    //if (key != 17) alert(key);
     if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
     {
          show_wpcp_message('You are not allowed to copy content or view source');
          return false;
     }else
       return true;
     }
}
function disable_copy(e)
{  
  var elemtype = e.target.nodeName;
  var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
  elemtype = elemtype.toUpperCase();
  var checker_IMG = '';
  if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    if (smessage !== "" && e.detail == 2)
      show_wpcp_message(smessage);
    
    if (isSafari)
      return true;
    else
      return false;
  }  
}
function disable_copy_ie()
{
  var elemtype = window.event.srcElement.nodeName;
  elemtype = elemtype.toUpperCase();
  if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    //alert(navigator.userAgent.indexOf('MSIE'));
      //if (smessage !== "") show_wpcp_message(smessage);
    return false;
  }
}  
function reEnable()
{
  return true;
}
document.onkeydown = disableEnterKey;
document.onselectstart = disable_copy_ie;
if(navigator.userAgent.indexOf('MSIE')==-1)
{
  document.onmousedown = disable_copy;
  document.onclick = reEnable;
}
function disableSelection(target)
{
    //For IE This code will work
    if (typeof target.onselectstart!="undefined")
    target.onselectstart = disable_copy_ie;
    
    //For Firefox This code will work
    else if (typeof target.style.MozUserSelect!="undefined")
    {target.style.MozUserSelect="none";}
    
    //All other  (ie: Opera) This code will work
    else
    target.onmousedown=function(){return false}
    target.style.cursor = "default";
}
//Calling the JS function directly just after body load
window.onload = function(){disableSelection(document.body);};
//]]>
</script>
<script id="wpcp_disable_Right_Click" type="text/javascript">
  //<![CDATA[
  document.ondragstart = function() { return false;}
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  Disable context menu on images by GreenLava Version 1.0
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
      function nocontext(e) {
         return false;
      }
      document.oncontextmenu = nocontext;
  //]]>
</script>
<style>
.unselectable
{
-moz-user-select:none;
-webkit-user-select:none;
cursor: default;
}
html
{
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
}
</style>
<script id="wpcp_css_disable_selection" type="text/javascript">
var e = document.getElementsByTagName('body')[0];
if(e)
{
  e.setAttribute('unselectable',on);
}
</script>
<script type="text/javascript">
    window.onbeforeunload = function() {
        return "Are you sure you want to leave?";
    }
</script>
<script language="JavaScript">
/*function check(e)
{
alert(e.keyCode);
}*/
document.addEventListener('contextmenu', event => event.preventDefault());

document.onkeydown = function (e) {
      
      if(e.keyCode == 123) {
          alert("F12 disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 67) {
          alert("ctrl + c disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 85) {
          alert("ctrl + u disable");
          return false;
      }
      
}     
</script>




<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>





<style>
.loader {
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loader > img {
    width: 100px;
}

.loader.hidden {
    animation: fadeOut 1s;
    animation-fill-mode: forwards;
}

@keyframes fadeOut {
    100% {
        opacity: 0;
        visibility: hidden;
    }
}

.thumb {
    height: 100px;
    border: 1px solid black;
    margin: 10px;
}
</style>
<script>
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");
    loader.className += " hidden"; // class "loader hidden"
});
</script>
<div class="loader">
<img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." /></div>


<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>







<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #181818;
  opacity: 0.90;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #F0F0F0;
}
.fixed-nav-bar { position: fixed; top: 0; left: 0; z-index: 9999; width: 100%; height: 50px; background-color: ##333; }
</style>
<nav  class="fixed-nav-bar">
<ul>
 <li><a class="" href="start.html"><i class="fa fa-fw fa-home"></i>&nbsp;<?php echo $lang['home'] ?></a></li>
 <li><a class="" href="index.php"><i class="fa-solid fa-circle-info"></i>&nbsp;<?php echo $lang['about'] ?></a></li>
 <li><a class="" href="web.php"><i class="fa-sharp fa-solid fa-network-wired"></i></i></i>&nbsp;<?php echo $lang['web'] ?></a></li>
 <?php if ( $user_data['type'] === 'Test') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='owner.php'><i class='fa-solid fa-unlock'></i>&nbsp;".$lang['owner']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <li><a class="" href="profile.php"><img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="32" height="16"><?php echo $user_data['user_name']; ?></a></a></li>
 
 
  <?php
   $query = "select * from news";
   $query_run = mysqli_query($con, $query);
   $row = mysqli_num_rows($query_run);
  ?>
 <style>
  #count {
    border-radius: 50%;
    position: relative;
    top: -10px;
    left: -10px;
  }
 </style>
  <style>
      span.circle {
        background: #e3e3e3;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        color: #6e6e6e;
        display: inline-block;
        font-weight: bold;
        line-height: 18px;
        margin-right: 5px;
        text-align: center;
        width: 18px;
      }
</style>
 <li><a class="" href="read-news.php"><i class="fa-solid fa-bell"></i>&nbsp;<span class="circle" id="count"><?php echo $row ?></span></a></li>
  <style>
   li:last-child {
        float: right; /* last li item */
        top:10px;
    }
 </style>
  <li><a href="ssc.php"><img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?php echo $user_data['ssc']; ?></a></li>
</ul>
</nav>







<style>
    @media (max-width: 767px) {
        .hidden-mobile {
          display: none;
        }
    }
</style>
<style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #E8E8E8;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #F0F0F0;
}
</style>
<button onclick="topFunction()" id="myBtn" title="Go to top">  ^  </button>
<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>

<style>


.container{
    width: 1100px;
    height: 480px;
    display: flex;   
    background: rgb(238, 236, 236);
}

.container .videos{
    width: 20%;
    padding: 10px 0 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.container .videos video{
    width: 95%;
    height: 100px;
    margin: 10px;
    object-fit: cover;
    cursor: pointer;
    transition: 0.2s;
}

.container .videos video:nth-child(1){
    margin-top: 0;
}

.container .videos video:hover,
.container .videos .active{
    transform: scale(1.06);
    border: 3px solid black;
}

.container .main-video{
    width: 80%;
    padding: 10px;
}

.container .main-video video{
    width: 100%;
    height: 100%;
    object-fit: cover;
    border: 3px solid black;
}
</style>

<style>

button{
  cursor: pointer;
  outline: 0;
  color: #AAA;

}

.btn:focus {
  outline: none;
}

.green{
  color: green;
}

.red{
  color: red;
}
</style>

<script>
var btn1 = document.querySelector('#green');
var btn2 = document.querySelector('#red');

btn1.addEventListener('click', function() {
  
    if (btn2.classList.contains('red')) {
      btn2.classList.remove('red');
    } 
  this.classList.toggle('green');
  
});

btn2.addEventListener('click', function() {
  
    if (btn1.classList.contains('green')) {
      btn1.classList.remove('green');
    } 
  this.classList.toggle('red');
  
});
</script>


<script src="https://use.fontawesome.com/fe459689b4.js"></script>

<br>
<div class="article-container">
<a href="rss.xml"><i class="fa-sharp fa-solid fa-square-rss fa-lg"></i></a>
<select style="color:black;" onchange="location = this.value;">
 <option></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=en"><?php echo $lang['english'] ?></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=ar"><?php echo $lang['arabic'] ?></option>
</select>
<br><br>
<div class="container">
        <div class="videos">
            <video src="/videos/SSS Introduction.mp4" muted></video>
            <video class="active" src="" poster="https://i.postimg.cc/3wY8PLLV/thumbnail1.jpg" muted></video>
            <video src="" poster="https://i.postimg.cc/DZz2zS3c/thumbnail2.jpg" muted></video>
            <video src="" poster="https://i.postimg.cc/V6Hz0zYP/thumbnail3.jpg" muted></video>
        </div>
        <div class="main-video">
            <video src="" poster="" muted controls autoplay></video>
            <br><br>
            <script src="https://apis.google.com/js/platform.js"></script>

            <div class="cont" style="position:relative; left:-410px;width:5px;height:auto;color:black;">
                <p>S.S.Scriptties</p><br><p>//////////////////////////////////////////////////////////////////<br>
                <?php echo $lang['vidd'] ?></p>
            </div>
            <div style="float:left;">
            <button width="50px" height="50px" class="btn" id="green"><i class="fa fa-thumbs-up fa-lg" aria-hidden="true"></i></button>
            <button width="50px" height="50px" class="btn" id="red"><i class="fa fa-thumbs-down fa-lg" aria-hidden="true"></i></button>
            </div>
        </div>
</div>
<div class="container">


        <div class="videos">
        <video src="" poster="https://i.postimg.cc/DZz2zS3c/thumbnail2.jpg" muted></video>
        </div>

</div>

    <!-- jquery cdn link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>

        $(document).ready(function(){

            $('.videos video').click(function(){

                $(this).addClass('active').siblings().removeClass('active');

                var src = $(this).attr('src');
                $('.main-video video').attr('src',src);
            });
        });

    </script>

</div>
<br>
<br>

<img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" border="0">
<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</html>