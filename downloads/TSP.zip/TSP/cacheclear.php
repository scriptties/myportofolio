<?php

// Get the current time.
$time = time();

// Clear the cache for all files that were modified after the current time.
$files = glob('*.php');
foreach ($files as $file) {
  if (filemtime($file) > $time) {
    unlink($file);
  }
}

// Clear the browser cache.
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');

?>
