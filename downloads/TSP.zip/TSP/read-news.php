<?php
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



session_start();

include("connection.php");
include("functions.php");

error_reporting(0);

$user_data = check_login($con);
$user_data = check_key($con);

?>

<html>  
<head>  
    <title>News | S.S.S</title>
    



    <meta name="robots" content="noindex, nofollow" />
    
<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">

    
    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
      var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
       if(disclaimer){
           disclaimer.remove();
       }  
     });
    </script>

    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="robots" content="noindex, nofollow" />

    <body bgcolor="white">
    <style>
    body {
      font-family: Arial, sans-serif;
    }
    </style>
    <script id="wpcp_disable_selection" type="text/javascript">
    //<![CDATA[
    var image_save_msg='You Can Not Save images!';
    var no_menu_msg='Context Menu disabled!';
    var smessage = "Content is protected !!";
    function disableEnterKey(e)
    {
      if (e.ctrlKey){
         var key;
         if(window.event)
              key = window.event.keyCode;     //IE
         else
              key = e.which;     //firefox (97)
        //if (key != 17) alert(key);
         if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
         {
              show_wpcp_message('You are not allowed to copy content or view source');
              return false;
         }else
           return true;
         }
    }
    function disable_copy(e)
    {  
      var elemtype = e.target.nodeName;
      var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
      elemtype = elemtype.toUpperCase();
      var checker_IMG = '';
      if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
      if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
      {
        if (smessage !== "" && e.detail == 2)
          show_wpcp_message(smessage);
        
        if (isSafari)
          return true;
        else
          return false;
      }  
    }
    function disable_copy_ie()
    {
      var elemtype = window.event.srcElement.nodeName;
      elemtype = elemtype.toUpperCase();
      if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
      if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
      {
        //alert(navigator.userAgent.indexOf('MSIE'));
          //if (smessage !== "") show_wpcp_message(smessage);
        return false;
      }
    }  
    function reEnable()
    {
      return true;
    }
    document.onkeydown = disableEnterKey;
    document.onselectstart = disable_copy_ie;
    if(navigator.userAgent.indexOf('MSIE')==-1)
    {
      document.onmousedown = disable_copy;
      document.onclick = reEnable;
    }
    function disableSelection(target)
    {
        //For IE This code will work
        if (typeof target.onselectstart!="undefined")
        target.onselectstart = disable_copy_ie;
        
        //For Firefox This code will work
        else if (typeof target.style.MozUserSelect!="undefined")
        {target.style.MozUserSelect="none";}
        
        //All other  (ie: Opera) This code will work
        else
        target.onmousedown=function(){return false}
        target.style.cursor = "default";
    }
    //Calling the JS function directly just after body load
    window.onload = function(){disableSelection(document.body);};
    //]]>
    </script>
    <script id="wpcp_disable_Right_Click" type="text/javascript">
      //<![CDATA[
      document.ondragstart = function() { return false;}
      /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      Disable context menu on images by GreenLava Version 1.0
      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
          function nocontext(e) {
             return false;
          }
          document.oncontextmenu = nocontext;
      //]]>
    </script>
    <style>
    .unselectable
    {
    -moz-user-select:none;
    -webkit-user-select:none;
    cursor: default;
    }
    html
    {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    }
    </style>
    <script id="wpcp_css_disable_selection" type="text/javascript">
    var e = document.getElementsByTagName('body')[0];
    if(e)
    {
      e.setAttribute('unselectable',on);
    }
    </script>
    <script type="text/javascript">
        window.onbeforeunload = function() {
            return "Are you sure you want to leave?";
        }
    </script>
    <script language="JavaScript">
    /*function check(e)
    {
    alert(e.keyCode);
    }*/
    document.addEventListener('contextmenu', event => event.preventDefault());
    
    document.onkeydown = function (e) {
          
          if(e.keyCode == 123) {
              alert("F12 disabled");
              return false;
          }
          
          if(e.ctrlKey && e.keyCode == 67) {
              alert("ctrl + c disabled");
              return false;
          }
          
          if(e.ctrlKey && e.keyCode == 85) {
              alert("ctrl + u disable");
              return false;
          }
          
    }     
    </script>
    
    
    
    
    <style>
    /* width */
    ::-webkit-scrollbar {
      width: 10px;
    }
    
    /* Track */
    ::-webkit-scrollbar-track {
      background: #f1f1f1; 
    }
     
    /* Handle */
    ::-webkit-scrollbar-thumb {
      background: #888; 
    }
    
    /* Handle on hover */
    ::-webkit-scrollbar-thumb:hover {
      background: #555; 
    }
    </style>
    
    
    
    
    
    <style>
    .loader {
        position: fixed;
        z-index: 99;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: black;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    
    .loader > img {
        width: 100px;
    }
    
    .loader.hidden {
        animation: fadeOut 1s;
        animation-fill-mode: forwards;
    }
    
    @keyframes fadeOut {
        100% {
            opacity: 0;
            visibility: hidden;
        }
    }
    
    .thumb {
        height: 100px;
        border: 1px solid black;
        margin: 10px;
    }
    </style>
    <script>
    window.addEventListener("load", function () {
        const loader = document.querySelector(".loader");
        loader.className += " hidden"; // class "loader hidden"
    });
    </script>
    <div class="loader">
    <img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." /></div>
    
    
<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>
    
    
<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
    
    <style>
        @media (max-width: 767px) {
            .hidden-mobile {
              display: none;
            }
        }
    </style>
    <style>
    #myBtn {
      display: none;
      position: fixed;
      bottom: 20px;
      right: 30px;
      z-index: 99;
      font-size: 18px;
      border: none;
      outline: none;
      background-color: #E8E8E8;
      color: white;
      cursor: pointer;
      padding: 15px;
      border-radius: 4px;
    }
    
    #myBtn:hover {
      background-color: #F0F0F0;
    }
    </style>
    <button onclick="topFunction()" id="myBtn" title="Go to top">  ^  </button>
    <script>
    // Get the button
    let mybutton = document.getElementById("myBtn");
    
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};
    
    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }
    
    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
    </script>

</head>   

    <body>

        <body style="background-color:black;">
            
<?php

  if($_SERVER['REQUEST_METHOD'] == "POST") {

    $sql = ""; 
    $query = mysqli_query($con, $sql);

  }

?>

        <style>
        .button {
          width: 20%;
          height: auto;
          background-color: white;
          color: black;
          text-align: left;
          margin: 0;
          display:inline;
          float:left;
          
        }
        </style>


        <style>
            .sss {
              border-radius: 50%;
            }
        </style>
    
<style>
/* (A) FIXED WRAPPER */
.hwrap {
  overflow: hidden; /* HIDE SCROLL BAR */
  background: #eee;
}
 
/* (B) MOVING TICKER WRAPPER */
.hmove { display: flex; }

/* (C) ITEMS - INTO A LONG HORIZONTAL ROW */
.hitem {
  flex-shrink: 0;
  width: 100%;
  box-sizing: border-box;
  padding: 10px;
  text-align: center;
}
 
/* (D) ANIMATION - MOVE ITEMS FROM RIGHT TO LEFT */
/* 4 ITEMS -400%, CHANGE THIS IF YOU ADD/REMOVE ITEMS */
@keyframes tickerh {
  0% { transform: translate3d(100%, 0, 0); }
  100% { transform: translate3d(-400%, 0, 0); }
}
.hmove { animation: tickerh linear 15s infinite; }
.hmove:hover { animation-play-state: paused; }
</style>
    
<div class="hwrap"><div class="hmove">
  <div class="hitem">The S.S.S Project is currently open fo beta-testers.</div>
  <div class="hitem">Following updates will focus on anonymity.</div>
  <div class="hitem">A discord server focusing on the project has been made.</div>
  <div class="hitem">Currently there is only one person working on The S.S.S Project.</div>
</div></div>
        <?php
           $sql = "SELECT * FROM news ORDER BY news_date DESC";
           $result = mysqli_query($con, $sql);
           $queryResults = mysqli_num_rows($result);
           
           if ($queryResults > 0)
           {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo "<div style='background-color: white;'>
                <h3 style='color: darkgrey;'><img class='sss' src=".$row['news_image']." style='position:relative; left:11px; top:2px; margin-top: 15px;' width='70' height='70' />&nbsp;&nbsp;&nbsp;&nbsp;".$row['news_title']."&nbsp;&rarr;</h3>
                <p><center>".$row['news_content']."</center></a></p>
                <p style='margin: 0; display:inline; float:left;'><img src='https://i.postimg.cc/T15GdQJr/PFP.png' alt='SSS-Profile-Pictures' border='0' width='55' height='30'>".$row['news_author']."</p>
                <pre style='width: 450px;'><code class='language-html' style='background-color: green; color: white; text-align: left; width: 800px;'>&nbsp;".$row['news_type']."&nbsp;</pre></code>
                <br><pre style='width: 450px;'><code class='language-html' style='background-color: grey; color: white; margin: 0; display:inline; float:left;'>&nbsp;".$row['news_date']."&nbsp;</pre></code>
                <pre style='width: 450px;'><code class='language-html' style='background-color: green; color: white; text-align: left; width: 800px;'>&nbsp;The S.S.S Project Demo&nbsp;</pre></code>
                </div>";
            } 
           }
        ?>
    </body>
<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</html>