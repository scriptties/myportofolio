-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 16, 2023 at 08:25 PM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id20109338_login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `a_id` int(11) NOT NULL,
  `a_title` varchar(256) NOT NULL,
  `a_text` text NOT NULL,
  `a_author` varchar(256) NOT NULL,
  `a_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chatroom2`
--

CREATE TABLE `chatroom2` (
  `chatroom2_name` varchar(255) NOT NULL,
  `chatroom2_message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chatroom2`
--

INSERT INTO `chatroom2` (`chatroom2_name`, `chatroom2_message`) VALUES
('s.s.scriptties', 'test'),
('s.s.scriptties', 'testing'),
('rer', 'erer'),
('rrr', 'rerer');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `message`) VALUES
(1, 's.s.scriptties', 'testing testing testing'),
(2, 's.s.scriptties', 'jus checking if this works'),
(3, 's.s.scriptties', 'checking if scrolling works'),
(4, 'name', 'message'),
(5, 'name', 'message'),
(6, 'name', 'message'),
(7, 'name', 'message'),
(8, 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `log_id` int(11) NOT NULL,
  `login_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`log_id`, `login_time`) VALUES
(1, '1688150538'),
(2, '1688669453'),
(3, '1688733361'),
(4, '1688837134'),
(5, '1689028564');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `downloads` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `size`, `downloads`) VALUES
(1, 'admin sb3.zip', 251283, 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_image` varchar(255) NOT NULL,
  `news_title` varchar(255) NOT NULL,
  `news_content` longtext NOT NULL,
  `news_author` varchar(255) NOT NULL,
  `news_type` enum('News','Update','Anime','Event') NOT NULL DEFAULT 'News',
  `news_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_image`, `news_title`, `news_content`, `news_author`, `news_type`, `news_date`) VALUES
(2, 'https://i.postimg.cc/bNyjbFys/sssnews.jpg', 'S.S.S Android Application', 'The S.S.S Team will soon give you access to our android application as a substitute to the website on android devices...', 'S.S.Scriptties(Head-Admin)', 'Update', '2023-02-03 17:53:29'),
(3, 'https://i.postimg.cc/bNyjbFys/sssnews.jpg', 'S.S.S Leaking Personal Info', 'The S.S.S Hacker Team has been taking personal info of pedophilic discord users\r\n(who distribute Child pornography, chat with other users in an illegal manner regarding children, and etc.) and leaking it to accounts that have ill intent against them...', 'S.S.Scriptties(Head-Admin)', 'News', '2023-02-03 18:32:19');

-- --------------------------------------------------------

--
-- Table structure for table `pass`
--

CREATE TABLE `pass` (
  `id` bigint(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `type` enum('Head-Admin','Admin','User','Test') NOT NULL,
  `ssc` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pass`
--

INSERT INTO `pass` (`id`, `user_name`, `password`, `type`, `ssc`) VALUES
(18340953058, 'S.S.Scriptties', ':y#=B5#957BW;:^R', 'Head-Admin', 999883);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(100) NOT NULL,
  `price` double(9,2) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `price`, `image`) VALUES
(1, 'test', 'test', 5.00, 'https://static.vecteezy.com/system/resources/thumbnails/004/588/660/small/check-test-line-icon-outline-sign-linear-style-pictogram-isolated-on-white-clipboard-with-tick-symbol-logo-illustration-editable-stroke-free-vector.jpg'),
(2, 'test2', 'test2', 2.05, 'https://static.vecteezy.com/system/resources/thumbnails/004/588/660/small/check-test-line-icon-outline-sign-linear-style-pictogram-isolated-on-white-clipboard-with-tick-symbol-logo-illustration-editable-stroke-free-vector.jpg'),
(3, 'test3', 'test3', 4.80, 'https://static.vecteezy.com/system/resources/thumbnails/004/588/660/small/check-test-line-icon-outline-sign-linear-style-pictogram-isolated-on-white-clipboard-with-tick-symbol-logo-illustration-editable-stroke-free-vector.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `p_comments`
--

CREATE TABLE `p_comments` (
  `p_name` varchar(45) NOT NULL,
  `p_message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `p_comments`
--

INSERT INTO `p_comments` (`p_name`, `p_message`) VALUES
('S.S.Scriptties', 'just testing if this works, messages will get deleted over\r\ntime for storage and privacy reasons');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` enum('Head-Admin','Admin','User','Test') NOT NULL DEFAULT 'User',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `email`, `password`, `type`, `date`) VALUES
(1, 18340953058, 'S.S.Scriptties', 'Owner@SSS.com', 'z\'($,,zVS6y-Z\"5A', 'Head-Admin', '2023-07-16 20:24:45'),
(2, 51235837, 'friend_user', 'friend@SSS.com', 'GU=,D;t=N5}8@w-q', 'User', '2023-03-24 11:35:29'),
(3, 9030, 'user', 'user@SSS.com', '\\w)q2K^U#{r3W@Bc', 'User', '2023-07-16 20:24:19'),
(4, 95008239, 'test_user', 'test@SSS.com', 'v69y>2\"E~3B<&s(q', 'Test', '2023-07-16 20:24:03'),
(5, 49765383681, 'beta_tester1', 'betatester1@SSS.com', 'hA4F%:_4wQt+K\"b=', 'Head-Admin', '2023-07-16 20:24:59'),
(6, 251435423, 'beta_tester2', 'betatester2@SSS.com', 'xT`#U7H(KmfY~(S3', 'Admin', '2023-03-24 11:38:44'),
(7, 69329650, 'beta_tester3', 'betatester3@SSS.com', '5&f4T<s~mdH^e)A:', 'User', '2023-03-24 11:41:06'),
(8, 703398416952926, 'beta_tester4', 'betatester4@SSS.com', ';b-8f*=Ck:M{q2fj', 'Test', '2023-03-24 11:41:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `pass`
--
ALTER TABLE `pass`
  ADD PRIMARY KEY (`user_name`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `email` (`email`),
  ADD KEY `date` (`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
