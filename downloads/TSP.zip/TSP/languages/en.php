<?php

$lang = array(
    
    
       "english" => "English",
       "arabic" => "Arabic",
       
       
       
       
       "home" => "Home",
       "about" => "About",
       "web" => "Web",
       "admin" => "Admin",
       "owner" => "Owner",
       "testing" => "Testing",
       
       
       
       
       "description" => "Free Speech,<br> No Censorship,<br> anonymity,<br>Anarchy.",
       "logout" => "Logout",
       "greeting" => "Hello",
       "show" => "Show More Videos",
       "show2" => "Show Demo",
       "sections" => "S.S.S Website Sections",
       
       
       
       "pgpc" => "PGP Copy",
       "pgpr" => "Request PGP Public Key",
       "comingsoon" => "COMING SOON",
       "warning" => "Once you submit the site will automatically be put in the database, Admins will observe it and determine whether it is malicious/unwanted or acceptable.",
       "warning2" => "The S.S.S Organization/Empire has nothing to do with what our partners do in there servers, if a certain partner and or<br> member of a partnered server, website, or team were to do something bad in any way it would not be our problem.",
       
       
       "gb1" => "MODS/CRACKS/TWEAKS/LEAKS | S.S.S",
       "gb2" => "YouTube Gaming | S.S.S",
       
       "shop" => "Shopping Cart",
       "cart" => "Cart",
       "buy" => "Buy now",
       "item" => "ITEM NAME",
       "q" => "QUANTITY",
       "price" => "UNIT PRICE",
       "total" => "ITEMS TOTAL",
       "tot" => "TOTAL",
       "remove" => "Remove Item",
       
       
       
       "site" => "Add Site To Search Engine",
       "terms" => "Search Terms/Key Words",
       "pages" => "Featured Pages",
       "search" => "Search",
       
       
       "up" => "Upload your file here...",
       "upb" => "Upload",
       "upid" => "ID",
       "upfn" => "Filename",
       "ups" => "size (in mb)",
       "upd" => "Downloads",
       "upa" => "Action",
       
       
       "on1" => ".Onion link | S.S.S",
       "on2" => ".Onion Chat | S.S.S",
       "on3" => "<i class='fa-brands fa-discord'></i> | S.S.S",
       
       
       "featured" => "Featured",
       "featured2" => "Approved By Head-Admin",
       "book1A" => "A delusional actor with an eating disorder and anti-social tendencies has <br>an obsession with acting in plays, he does it so much that he disregards<br> eating, sleep, and general needs.",
       "book1B" => "Read and see what happens next...",
       "book2A" => "A man comes back after killing himself and uses this second chance to <br>do everything he never could, he becomes addicted to adrenaline and <br>becomes a slave to worldy desires.",
       "book2B" => "Read and see what happens next...",
       "book3A" => "COMING SOON",
       "book3B" => "Read and see what happens next...",
       
       "mc" => "Edition server",
       "ip" => "IP:",
       "port" => "Port:",
       "name" => "Name:",
       "version" => "Version:",
       "status" => "Status:",
       "copy" => "Copy Info",
       "copy2" => "Copy Code",
       
       "cases" => "Cases",
       "vidd" => "All&nbsp;Videos&nbsp;Shown&nbsp;May&nbsp;Include&nbsp;Content&nbsp;that&nbsp;may&nbsp;offend&nbsp;a&nbsp;snowflake,&nbsp;stop&nbsp;being&nbsp;woke&nbsp;and&nbsp;bitchy.",
       "pro1" => "Child Expo Entry",
       "pro2" => "Science Fair",
       "pop1" => "populate habitat",
       "pop2" => "de-populate habitat",
       "pop3" => "view lion attack",
       "pop4" => "volcano eruption",
       
       
       
       "exp1" => "Splitting water into hydrogen and oxygen presents an alternative to fossil fuels, but purified water is a precious resource. new way of separating hydrogen and oxygen gas from seawater via electricity. Existing water-splitting methods rely on highly purified water, which is a precious resource and costly to produce.Theoretically, to power cities and cars, “you need so much hydrogen it is not conceivable to use purified water,” said Hongjie Dai, J.G. Jackson and C.J. Wood professor in chemistry in Stanford’s School of Humanities and Sciences and co-senior author on the paper. “We barely have enough water for our current needs in California.”Hydrogen is an appealing option for fuel because it doesn’t emit carbon dioxide, Dai said. Burning hydrogen produces only water and should ease worsening climate change problems.Dai said his lab showed proof-of-concept with a demo, but the researchers will leave it up to manufacturers to scale and mass produce the design.",
       "exp2" => "Surprisingly simple Looking back, Dai and Kenney can see the simplicity of their design. “If we had a crystal ball three years ago, it would have been done in a month,” Dai said. But now that the basic recipe is figured out for electrolysis with seawater, the new method will open doors for increasing the availability of hydrogen fuel powered by solar or wind energy. In the future, the technology could be used for purposes beyond generating energy. Since the process also produces breathable oxygen, divers or submarines could bring devices into the ocean and generate oxygen down below without having to surface for air. In terms of transferring the technology, “one could just use these elements in existing electrolyzer systems and that could be pretty quick,” Dai said. “It’s not like starting from zero – it’s more like starting from 80 or 90 percent.”",
       "exp3" => "Tackling corrosion As a concept, splitting water into hydrogen and oxygen with electricity – called electrolysis – is a simple and old idea: a power source connects to two electrodes placed in water. When power turns on, hydrogen gas bubbles out of the negative end – called the cathode – and breathable oxygen emerges at the positive end – the anode. But negatively charged chloride in seawater salt can corrode the positive end, limiting the system’s lifespan. Dai and his team wanted to find a way to stop those seawater components from breaking down the submerged anodes. The researchers discovered that if they coated the anode with layers that were rich in negative charges, the layers repelled chloride and slowed down the decay of the underlying metal. They layered nickel-iron hydroxide on top of nickel sulfide, which covers a nickel foam core. The nickel foam acts as a conductor – transporting electricity from the power source – and the nickel-iron hydroxide sparks the electrolysis, separating water into oxygen and hydrogen. During electrolysis, the nickel sulfide evolves into a negatively charged layer that protects the anode. Just as the negative ends of two magnets push against one another, the negatively charged layer repels chloride and prevents it from reaching the core metal. Without the negatively charged coating, the anode only works for around 12 hours in seawater, according to Michael Kenney, a graduate student in the Dai lab and co-lead author on the paper. “The whole electrode falls apart into a crumble,” Kenney said. “But with this layer, it is able to go more than a thousand hours.” Previous studies attempting to split seawater for hydrogen fuel had run low amounts of electric current, because corrosion occurs at higher currents. But Dai, Kenney and their colleagues were able to conduct up to 10 times more electricity through their multi-layer device, which helps it generate hydrogen from seawater at a faster rate.",
       "ce1" => "Play Demo",
       "ce2" => "Files",
       "token" => "Session Token:",
       
       
       
       "balance" => "Your Balance",
       "how" => "How to get SSC (Scripties Coins)",
       "ways" => "There are 3 ways to get SSC",
       "project" => "Projects",
       "projectd" => "You can get SSC coins by making projects and sharing it on the platform or adding them to the soosle search engine, you <br> can also get SSC coins by being active in our community.",
       "projectb" => "Add Site/Chat",
       "event" => "Events",
       "eventd" => "you can get SSC coins by joining events hosted on this platform, for example: game jams, capture the flag, and more related events. winners will get the amount of SSC specified by the event host, the reward amount will always be mentioned before an event.",
       "eventb" => "Join a Event",
       "payment" => "Payment",
       "paymentd" => "SSC can be purchased using USD or Monero (XMR), 3$ is 1SSC, 0.000012XMR is 2SSC, Prices might get higher and higher as this is the only way the project can get money. ",
       "paymentb" => "Buy",
       
       
       "reward" => "Most Rewarding",
       "popular" => "Popular",
       
       "login" => "Login",
       "Click to Signup" => "Click to Signup",
       "user name" => "user name",
       "password" => "password",
       "Fake Email" => "Fake Email",
       "Signup"=>  "Signup",
       "Private Key" => "Private Key",
       "Private Keyd" => "A private key is the key given by an admin or head admin<br> for access of the website, everybody has a unique private key.<br> Note: Never forget your private key, because even admins can't see it.<br>(if your an admin and forgot your private key verify your info with a head admin)",
    );

?>