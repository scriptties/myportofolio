<?php

session_start();

if(isset($_SESSION['user_id']))
{
    unset($_SESSION['user_id']);
}

if(isset($_SESSION['private_key']))
{
    unset($_SESSION['private_key']);
}

header("Location: login.php");
die;
?>