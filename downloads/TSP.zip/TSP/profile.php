<?php 
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

session_start();

	include("connection.php");
	include("functions.php");
	include("config.php");

	$user_data = check_login($con);
	$user_data = check_key($con);
    $token =  random_num(80);
    $_SESSION['token'] = $token;

?>
<!DOCTYPE html>
<html lang="en-US">
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">


<style>
html {
  font-size: 15px;
}
</style>

<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>



    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script>
    
<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="robots" content="noindex, nofollow" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Profile | S.S.S</title>
<style>
body {
  font-family: Arial, sans-serif;
}
</style>
<script id="wpcp_disable_selection" type="text/javascript">
//<![CDATA[
var image_save_msg='You Can Not Save images!';
var no_menu_msg='Context Menu disabled!';
var smessage = "Content is protected !!";
function disableEnterKey(e)
{
  if (e.ctrlKey){
     var key;
     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox (97)
    //if (key != 17) alert(key);
     if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
     {
          show_wpcp_message('You are not allowed to copy content or view source');
          return false;
     }else
       return true;
     }
}
function disable_copy(e)
{  
  var elemtype = e.target.nodeName;
  var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
  elemtype = elemtype.toUpperCase();
  var checker_IMG = '';
  if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    if (smessage !== "" && e.detail == 2)
      show_wpcp_message(smessage);
    
    if (isSafari)
      return true;
    else
      return false;
  }  
}
function disable_copy_ie()
{
  var elemtype = window.event.srcElement.nodeName;
  elemtype = elemtype.toUpperCase();
  if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    //alert(navigator.userAgent.indexOf('MSIE'));
      //if (smessage !== "") show_wpcp_message(smessage);
    return false;
  }
}  
function reEnable()
{
  return true;
}
document.onkeydown = disableEnterKey;
document.onselectstart = disable_copy_ie;
if(navigator.userAgent.indexOf('MSIE')==-1)
{
  document.onmousedown = disable_copy;
  document.onclick = reEnable;
}
function disableSelection(target)
{
    //For IE This code will work
    if (typeof target.onselectstart!="undefined")
    target.onselectstart = disable_copy_ie;
    
    //For Firefox This code will work
    else if (typeof target.style.MozUserSelect!="undefined")
    {target.style.MozUserSelect="none";}
    
    //All other  (ie: Opera) This code will work
    else
    target.onmousedown=function(){return false}
    target.style.cursor = "default";
}
//Calling the JS function directly just after body load
window.onload = function(){disableSelection(document.body);};
//]]>
</script>
<script id="wpcp_disable_Right_Click" type="text/javascript">
  //<![CDATA[
  document.ondragstart = function() { return false;}
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  Disable context menu on images by GreenLava Version 1.0
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
      function nocontext(e) {
         return false;
      }
      document.oncontextmenu = nocontext;
  //]]>
</script>
<style>
.unselectable
{
-moz-user-select:none;
-webkit-user-select:none;
cursor: default;
}
html
{
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
}
</style>
<script id="wpcp_css_disable_selection" type="text/javascript">
var e = document.getElementsByTagName('body')[0];
if(e)
{
  e.setAttribute('unselectable',on);
}
</script>
<script type="text/javascript">
    window.onbeforeunload = function() {
        return "Are you sure you want to leave?";
    }
</script>
<script language="JavaScript">
/*function check(e)
{
alert(e.keyCode);
}*/
document.addEventListener('contextmenu', event => event.preventDefault());

document.onkeydown = function (e) {
      
      if(e.keyCode == 123) {
          alert("F12 disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 67) {
          alert("ctrl + c disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 85) {
          alert("ctrl + u disable");
          return false;
      }
      
}     
</script>
<style>
      @media (max-width: 767px) {
        .hidden-mobile {
          display: none;
        }
      }
</style>





<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>







<style>
.loader {
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loader > img {
    width: 100px;
}

.loader.hidden {
    animation: fadeOut 1s;
    animation-fill-mode: forwards;
}

@keyframes fadeOut {
    100% {
        opacity: 0;
        visibility: hidden;
    }
}

.thumb {
    height: 100px;
    border: 1px solid black;
    margin: 10px;
}
</style>
<script>
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");
    loader.className += " hidden"; // class "loader hidden"
});
</script>
<div class="loader">
<img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." /></div>
<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>
</head>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<body>
<center>

</center>
<center>
<div style="background-color:#181818;color:white;padding:30px">
<br>
<a href="rss.xml"><i class="fa-sharp fa-solid fa-square-rss fa-lg"></i></a>
<select onchange="location = this.value;">
 <option></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=en"><?php echo $lang['english'] ?></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=ar"><?php echo $lang['arabic'] ?></option>
</select>
<br>
<br>
<br>
<br>
<img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="70%" height="auto"></a>
<br>
<br>
<br>
<i class="fa-solid fa-user"></i> &nbsp; <?= htmlspecialchars($user_data['user_name']); ?>
<br>
<img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?= htmlspecialchars($user_data['ssc']); ?>
<br>
<i class="fa-solid fa-key"></i> &nbsp; <?= htmlspecialchars($user_data['password']); ?>
<br>
<br>
<i class="fa-solid fa-circle-user"></i> &nbsp; <?= htmlspecialchars($user_data['type']); ?>
<br>
<br>
<?php echo "".$lang['token']." <br> $token"?>
<br>
<br>
<a href="logout.php"><?php echo $lang['logout'] ?></a>
<br>
</div>

</center>
<center><div><img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" alt="Powered-By-SSS-removebg-preview" border="0"></div></center>
<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</body>
