<?php

// Check if the website is using HTTPS
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] != 'on') {
    echo 'Your website is not using HTTPS. This is a security risk.';
}

// Check if the website has a modern theme
if (preg_match('/\d{4}-\d{2}-\d{2}/', $_SERVER['HTTP_USER_AGENT']) == false) {
    echo 'Your website is using an outdated theme. This is a security risk.';
}

// Check the URL
if (preg_match('/\.php$/', $_SERVER['REQUEST_URI']) == true) {
    echo 'Your website is using a PHP extension in the URL. This is a security risk.';
}

// Be wary of security seals
if (preg_match('/security-seal.com/', $_SERVER['HTTP_REFERER']) == true) {
    echo 'Your website is using a security seal from a website that is not well-known. This is a security risk.';
}

// Escape spam
if (preg_match('/viagra/', $_SERVER['REQUEST_URI']) == true) {
    echo 'Your website is being targeted by spam. This is a security risk.';
}

?>
