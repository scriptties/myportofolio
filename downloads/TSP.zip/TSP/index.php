<?php 
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

require 'security/shieldon/autoload.php';
include("security/DDoS.php");

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


error_reporting(0);

session_start();

	include("connection.php");
	include("functions.php");
	include("config.php");


	$user_data = check_login($con);
	$user_data = check_key($con);
?>

<!DOCTYPE html>
<html lang="en-US">
<meta name="robots" content="noindex, nofollow" />

<link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">



<style>
html {
  font-size: 15px;
}
</style>
    
    <script>
        if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
        }
    </script> 
    
<style>
video {
  height: auto;
  width: 75%;
}

</style>

<style>
html, body {
     min-width: 100%;
     min-height: 100%;
}
</style>

    
<script>

</script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  var disclaimer =  document.querySelector("img[alt='www.000webhost.com']");
   if(disclaimer){
       disclaimer.remove();
   }  
 });
</script>
    
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
	<title>About | S.S.S</title>


<style>
body::before {
  content: "";
  position: fixed;
  top: -10px;
  left: 0;
  width: 100%;
  height: 10px;
  box-shadow: 0px 0 10px rgba(0, 0, 0, 0.8);
  z-index: 100;
}
</style>

<div class="loader">
    <img src="https://i.postimg.cc/BbF6YJk9/Loading.gif" alt="Loading..." />
</div>

<script id="wpcp_disable_selection" type="text/javascript">
//<![CDATA[
var image_save_msg='You Can Not Save images!';
var no_menu_msg='Context Menu disabled!';
var smessage = "Content is protected !!";
function disableEnterKey(e)
{
  if (e.ctrlKey){
     var key;
     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox (97)
    //if (key != 17) alert(key);
     if (key == 97 || key == 65 || key == 67 || key == 99 || key == 88 || key == 120 || key == 26 || key == 85  || key == 86 || key == 83 || key == 43)
     {
          show_wpcp_message('You are not allowed to copy content or view source');
          return false;
     }else
       return true;
     }
}
function disable_copy(e)
{  
  var elemtype = e.target.nodeName;
  var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
  elemtype = elemtype.toUpperCase();
  var checker_IMG = '';
  if (elemtype == "IMG" && checker_IMG == 'checked' && e.detail >= 2) {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    if (smessage !== "" && e.detail == 2)
      show_wpcp_message(smessage);
    
    if (isSafari)
      return true;
    else
      return false;
  }  
}
function disable_copy_ie()
{
  var elemtype = window.event.srcElement.nodeName;
  elemtype = elemtype.toUpperCase();
  if (elemtype == "IMG") {show_wpcp_message(alertMsg_IMG);return false;}
  if (elemtype != "TEXT" && elemtype != "TEXTAREA" && elemtype != "INPUT" && elemtype != "PASSWORD" && elemtype != "SELECT" && elemtype != "OPTION" && elemtype != "EMBED")
  {
    //alert(navigator.userAgent.indexOf('MSIE'));
      //if (smessage !== "") show_wpcp_message(smessage);
    return false;
  }
}  
function reEnable()
{
  return true;
}
document.onkeydown = disableEnterKey;
document.onselectstart = disable_copy_ie;
if(navigator.userAgent.indexOf('MSIE')==-1)
{
  document.onmousedown = disable_copy;
  document.onclick = reEnable;
}
function disableSelection(target)
{
    //For IE This code will work
    if (typeof target.onselectstart!="undefined")
    target.onselectstart = disable_copy_ie;
    
    //For Firefox This code will work
    else if (typeof target.style.MozUserSelect!="undefined")
    {target.style.MozUserSelect="none";}
    
    //All other  (ie: Opera) This code will work
    else
    target.onmousedown=function(){return false}
    target.style.cursor = "default";
}
//Calling the JS function directly just after body load
window.onload = function(){disableSelection(document.body);};
//]]>
</script>
<script id="wpcp_disable_Right_Click" type="text/javascript">
  //<![CDATA[
  document.ondragstart = function() { return false;}
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  Disable context menu on images by GreenLava Version 1.0
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
      function nocontext(e) {
         return false;
      }
      document.oncontextmenu = nocontext;
  //]]>
</script>
<style>
.unselectable
{
-moz-user-select:none;
-webkit-user-select:none;
cursor: default;
}
html
{
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
}
</style>
<script id="wpcp_css_disable_selection" type="text/javascript">
var e = document.getElementsByTagName('body')[0];
if(e)
{
  e.setAttribute('unselectable',on);
}
</script>
<script type="text/javascript">
    window.onbeforeunload = function() {
        return "Are you sure you want to leave?";
    }
</script>
<script language="JavaScript">
/*function check(e)
{
alert(e.keyCode);
}*/
document.addEventListener('contextmenu', event => event.preventDefault());

document.onkeydown = function (e) {
      
      if(e.keyCode == 123) {
          alert("F12 disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 67) {
          alert("ctrl + c disabled");
          return false;
      }
      
      if(e.ctrlKey && e.keyCode == 85) {
          alert("ctrl + u disable");
          return false;
      }
      
}     
</script>







<link rel="stylesheet" href="fontawesome-6.4.0/css/all.min.css">
<link rel="stylesheet" href="fontawesome-6.4.0/css/fontawesome.min.css">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #181818;
  opacity: 0.90;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #F0F0F0;
}
.fixed-nav-bar { position: fixed; top: 0; left: 0; z-index: 9999; width: 100%; height: 50px; background-color: ##333; }
</style>
<nav  class="fixed-nav-bar">
<ul>
 <li><a class="" href="start.html"><i class="fa fa-fw fa-home"></i>&nbsp;<?php echo $lang['home'] ?></a></li>
 <li><a class="" href="web.php"><i class="fa-sharp fa-solid fa-network-wired"></i></i></i>&nbsp;<?php echo $lang['web'] ?></a></li>
 <?php if ( $user_data['type'] === 'Test') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp; ".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='admin.php'><i class='fa-solid fa-lock'></i>&nbsp;".$lang['admin']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='owner.php'><i class='fa-solid fa-unlock'></i>&nbsp;".$lang['owner']."</a></li>";
 } ?>
 <?php if ( $user_data['type'] === 'Head-Admin') {
   echo "<li><a class='active' href='testing.php'><i class='fa-solid fa-microscope'></i>&nbsp;".$lang['testing']."</a></li>";
 } ?>
 <li><a class="" href="profile.php"><img src="https://i.postimg.cc/T15GdQJr/PFP.png" alt="SSS-Profile-Pictures" border="0" width="32" height="16"><?php echo $user_data['user_name']; ?></a></a></li>
  <?php
   $query = "select * from news";
   $query_run = mysqli_query($con, $query);
   $row = mysqli_num_rows($query_run);
  ?>
  <style>
  #count {
    border-radius: 50%;
    position: relative;
    top: -10px;
    left: -10px;
  }
 </style>
  <style>
      span.circle {
        background: #e3e3e3;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        color: #6e6e6e;
        display: inline-block;
        font-weight: bold;
        line-height: 18px;
        margin-right: 5px;
        text-align: center;
        width: 18px;
      }
</style>
 <li><a class="" href="read-news.php"><i class="fa-solid fa-bell"></i>&nbsp;<span class="circle" id="count"><?php echo $row ?></span></a></li>
  <style>
   li:last-child {
        float: right; /* last li item */
        top:10px;
    }
 </style>
  <li><a href="ssc.php"><img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"><?php echo $user_data['ssc']; ?></a></li>
</ul>

</nav>




        <style>
            body {
                margin: 0;
                padding: 0;
            }
   
            div {
                margin: 0;
            }

            .wrapper {
                height: 100vh;
                overflow-y: auto;
                overflow-x: hidden;
                perspective: 10px;
            }

            header {
                position: relative;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100%;
                transform-style: preserve-3d;
                z-index: -1;
            }

            .background {
                transform: translateZ(-10px) scale(2);
            }

            .foreground {
                transform: translateZ(-4.5px) scale(1.5);
            }

            .background,
            .foreground {
                position: absolute;
                height: 100%;
                width: 100%;
                object-fit: cover;
                z-index: -1;
            }

            .title {
                font-size: 7rem;
                color: white;
                text-shadow: 0 0 5px black;
                text-align: center;
            }

            .subtitle {
                color: white;
                text-shadow: 0 0 5px black;
                text-align: center;
            }

            .section1 {
                padding: 2rem;
                background-color: black;
            }
        </style>
        
        
<div style="background-color: white;">
<div class="wrapper">
<header>
   <img src="https://i.postimg.cc/yxhwL51Y/bg1png.png" class="background">
   <img src="https://i.postimg.cc/65ts89c7/bg2png.png" class="foreground">
   <br><br><br><br>
   <h1 class="title">S.S.S</h1>
   <p class="subtitle"> <?php echo $lang['description'] ?> </p>
</header>
<center>
<section class="section1">
    
    
    


<style>
 a.button3{
 display:inline-block;
 padding:0.3em 1.2em;
 margin:0 0.3em 0.3em 0;
 border-radius:2em;
 box-sizing: border-box;
 text-decoration:none;
 font-family:'Roboto',sans-serif;
 font-weight:300;
 color:#E8E8E8;
 background-color:black;
 text-align:center;
 transition: all 0.2s;
}
a.button3:hover{
 background-color:#F0F0F0;
}
@media all and (max-width:30em){
 a.button3{
  display:block;
  margin:0.2em auto;
 }
}
</style>
<style>
img.rounded-corners {
  border-radius: 15px;
}
</style>
<br>
<br>
<br>
<br>

<a href="rss.xml"><i class="fa-sharp fa-solid fa-square-rss fa-lg"></i></a>

<style>
.loader {
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loader > img {
    width: 100px;
}

.loader.hidden {
    animation: fadeOut 1s;
    animation-fill-mode: forwards;
}

@keyframes fadeOut {
    100% {
        opacity: 0;
        visibility: hidden;
    }
}

.thumb {
    height: 100px;
    border: 1px solid black;
    margin: 10px;
}
</style>
<script>
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");
    loader.className += " hidden"; // class "loader hidden"
});
</script>

 


<style>
::-webkit-scrollbar {
  display: none;
}
</style>

<link rel="stylesheet" type="text/css" href="bootstrap-5.3.0/css/bootstrap.min.css">
<script type="text/javascript" src="bootstrap-5.3.0/js/bootstrap.min.js"></script>
<script src="jquery-3.7.0/jquery.js"></script>
<script src="jquery-3.7.0/jquery.min.js"></script>

</head>
<body>


<select onchange="location = this.value;">
 <option></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=en"><?php echo $lang['english'] ?></option>
 <option value="<?php echo $_SERVER['PHP_SELF'] ?>?lang=ar"><?php echo $lang['arabic'] ?></option>
</select>
<br><br>

<center>
	<a href="logout.php"><?php echo $lang['logout'] ?></a>

	<br>
	<?php echo $lang['greeting'] ?>, <?php echo $user_data['user_name']; ?>


	<body style="background-color:black;">


<br>
<br>
<br>
<br>
<div style="background-color:white;color:white;padding:30px; border-radius: 20px;">
<br>
<br>

<style>
video {
    border: 5px solid black;
}
</style>



<video src="/videos/SSS Introduction.mp4" muted controls autoplay></video>
<br>

<a href="videos.php" class="button3"><?php echo $lang['show'] ?></a>
</div>


<br>
<br>
<br>
<br>
<br>
<div>
<img src="https://i.postimg.cc/d07pbDsf/about.jpg" alt="about" border="0" class="hidden-xs"></a>
<br>
<br>
<div style="background-color:white;color:white;padding:30px; border-radius:20px;">
    
<style>
input {
    padding: 0px 20px;
    width: 300px;
    height: 40px;
    font-size: 22px;
    color: black;
}
</style>

<p id="p1" style="background-color: #F0F0F0; color:black; border-radius: 20px;">
-----BEGIN PGP MESSAGE-----

hF4DgztFgdbJf70SAQdAvSvqmmvWig5cFz7IG0vEq7iMoNEjmCVxHTxN24W+EDQw
A9O8gyVvgDi0RYOlU7hF620+2Q3ZwTT3o8N0KWnljt4cl7NP7+02uYX+xJYD93fw
1OoBCQIQbymR/stCXDsbN3BMsJ6/HjJGzHxVX7xX8R9JUP4fVVOd2tUgioiwqLlb
Bizd9Z6Dzyx7Ry98s65znqftaAMpE9ac52KtZlG5hiOlBJOMi3LmdgjFrg7Ee5Mp
k2gL6txqk3IpNMTJc9TD3LWdeZoCyh+cLtkBwLREslKlahm5sXx8Y/cykGCg8a6f
hAHIgIRyfiCkcFGGTaYmKBjyEo+D7nf8oZD4IROjUqE9VI7twa+Q3gYDWjzXJp4P
PMOxFYhQb0wSnn3hWeXUsukoHaFnuCDvVTfDWzQXIWsBFrnToQ71qR/gd6PfsXFY
QOA3ZjNLGhuxT053MqgpDP26vzWN1vXmtzSOR7kEnhc5reD7PnrIiUZgZFY4JyP9
iStZJlnBqfHTIsQMyCMqIB+qSH9cTyWckhDOi09+Gwgz14hiMmr9BXkBZOG83m4h
zz9UfhFPvunvOZvViX8fE/I3kvUM369ByXImO04JYv4gtmVc99+8EUziJvUkj+YS
A0b2QYmLjCUTPI//uskc4dNHL+AwwoPBI5kQg/6KjAGCddaZigtK+dOaQ/HPWly+
iikh/q8IA1LFKtLqSo8mFPonr8e9Fy2Ahd3zFLpzxSHpl+t8FN+9zUExQpGcFzeg
nKGJtoyRZCjcX9C/metiizuIFZbz1xs4lY4o28Ky3xd9NUJy3sFtHZ1aeZIrmA/2
FqhFtXhGX1f9bbUmfaeedFpVhC7VdETZlRG8aspNInpN5omB6odb+yhTlzmsxPi1
tmoNg5jrXIT9NaFT6JShEvvm+3uChiJRKBZrtrJoY1/pTyFR8PEimJbGSLZFr1Qf
jaVxojQUS8vYzVCbfCB6wr7sQ6PeM7Vru2MSxefUfvP0MoiHKcCKYWHVt6nWfegp
U+90VCpu90ZpyFX644blr/X/zT5OKUqd+KhFaKtLvBzAK6zLPtc2cO+qiqIDW1Au
dm8YCwLHZN80eHJb9jRPAQ8Mf8OMRAZ9QYeZLqEpETPZlfPjPezrRKNyFa/PydWn
p1SqqHF07xlxYSPr9yWi+FCKDIr15ElGLd+m9iL8SO0AYSXItYiljxjGvBarQi1a
1hURwi+UZQv9HJbucMMd6NuUUKArSCnqBkB7pB6xsouoVjO3lEJdUq6xb1HTuSSG
S24fXbfpgkPugsYgf+TpRdJawamkzJ7ejlneoKF2bAomE722g3yKyAkyyy3KEQNL
DZOP319e487ggIU3vnVzqr8SzFU4Cb5JkKHXLv5DBwX+nH3LwF7yCrW/KX94OkEd
MhGJbDjDU+zr0Pi8zcNf60ih2HA3uiXDN5I6fXuWMdQ4EQRdG2F/yJ1dygeBaItU
SOvm5srcaAjk0ugp4GxWVqLFwCLW+WHlKaO45zjuTDUViDBVzLleT1ZoJDeDXmx+
DfqFrp1BjSkX1UFR7G+ay8bFnREbJ2TVVssBtrZua53s+h0BxJTEjAzCr/QtIOoP
wfNtvuYuDuso/9+67lsWan+S6G1FF3L+8sffrJ7X9B65RHs+JhvUWNIMtRNNvEqD
x4/5z8zzBtwZDJa1B+tR7q5Jx0nWDig2pmPpAC1DMpAh6qUBGZGgVDeBKCY5sEHk
NyNZzxxeny1v+8mQjwrkzmmE4efwayYvWPCVX8AvGNxuGb9o/bZ8qNtJNXWzBbF5
Ul/ttuiz
=SFYA
-----END PGP MESSAGE-----
</p>
<br>

<button onclick="copyToClipboard('#p1')"> <?php echo $lang['pgpc'] ?> </button>
<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>

<BUTTON ONCLICK="ShowAndHide()"> <?php echo $lang['pgpr'] ?> </BUTTON>
<SCRIPT>
function ShowAndHide() {
    var x = document.getElementById('SectionName');
    if (x.style.display == 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</SCRIPT>
<style>
button {
    background-color: lightgrey;
    border-radius: 10px;
}
button:hover {
    background-color: darkgrey;
}
button:active {
    background-color: grey;
}
</style>
<DIV ID="SectionName" class="rounded" STYLE="display:none;">
<br>
<p style="background-color: #F0F0F0; color: black;">
Contact "<b>scriptties@gtfcy37qyzor7kb6blz2buwuu5u7qjkycasjdf3yaslibkbyhsxub4yd.onion</b>" or chat in the "<b>Sexy.Support.Team</b>" chat.
</p>
</DIV>




</div>
<br>
<br>


<br>
<br>
<br>
<br>
<div style="background-color:white;color:white;padding:30px; border-radius: 20px;">
<a href="worlds.php" class="hidden-xs"><img src="https://i.postimg.cc/xT4PW5X0/ad1.jpg" class="rounded-corners" alt="S.S.S WORLDS AD" width="400" class="hidden-xs"
	height="100" border=" 9px solid #555;"  ></a>
<br>
<br>
<br>
<br>

<h1 style="color:black;">
<br>
<?php echo $lang['sections'] ?>
</h1>



<a href="links.php" class="button3">SSL&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S</a>

<a href="gaming.php" class="button3"> SGM&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S</a>

<a href="https://relaxed-raman-85b578.netlify.app/index.html" class="button3"> <img src="https://i.postimg.cc/VsT15yTn/SSC.png" alt="ssc" border="0" width="32" height="16"> SED&nbsp;<i class="fa-solid fa-triangle-exclamation"></i> | S.S.S</a>

<br>
<br>

<a href="shop.php" class="button3"> SOS | S.S.S</a>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="start.html" class="button3"> < </a>
 
<a href="" class="button3"> <i class="fa-sharp fa-solid fa-rotate-right"></i> </a>
 
<a href="web.php" class="button3"> > </a>

<br>
<br>
<br>
<br>
<a href="https://scriptties.github.io/admin-room/" class="hidden-xs"><img src="https://i.postimg.cc/SskLWtvG/ad7.jpg" class="rounded-corners" alt="S.S.S ADMIN AD" width="400" class="hidden-xs"
	height="100" border=" 9px solid #555;" ></a>
</div>
</div>

<br>
<br>
<br>
<br>
<br>
<div style="background-color:white;color:white;padding:30px; border-radius: 20px;">

<script>


// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
    

<center><img width="70%" height="auto" src="https://i.postimg.cc/mZK1Q5JW/PB1.png" border="0"></div></center>

<style>
a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
/* unvisited link */
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: darkgrey;
}

/* selected link */
a:active {
  color: darkgrey;
}
</style>
</section>
</center>
</div>
</div>





</body>
</html>