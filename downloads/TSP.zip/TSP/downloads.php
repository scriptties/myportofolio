<?php

ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);

// Get the file ID from the URL
$file_id = $file['id'];

// Get the file name from the database
$sql = "SELECT name FROM files WHERE id=$file_id";
$result = mysqli_query($con, $sql);
$file = mysqli_fetch_assoc($result);
$filename = $file['name'];

// Check if the file exists
if (!file_exists('uploads/' . $filename)) {
    // File does not exist
    echo 'File does not exist.';
    exit;
}


// Set the headers for the file download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename=' . basename($filename));
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize('uploads/' . $filename));


// Read the file and send it to the browser
readfile('uploads/' . $filename);

?>
