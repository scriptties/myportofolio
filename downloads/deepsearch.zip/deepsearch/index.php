<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="icon" type="image/x-icon" href="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">
    <head>
    <title>DeepSearch | S.S.S</title>
<style>
body {
    background-image: url("");
    background-color: whitesmoke;
}

input[type="search"] {
    width: 350px;
    height: 45px;
    padding-right: 50px;
    border: 1px solid white;
    box-sizing: border-box;
    border: 3px solid white;
    -webkit-transition: 0.5s;
    transition: 0.5s;
    outline: none;
}

input[type="search"]:focus {
  border: 3px solid white;
}

#bsearch-btn {
    margin-left: -50px;
    height: 45px;
    width: 70px;
    border-radius: 40px;
    border: 6px solid white;
}

input {
    padding: 0px 20px;
    width: 300px;
    height: 40px;
    font-size: 22px;
    color: black;
}

.search-button  {
  height: 40px;
  font-size: 22px;
}

p {
  background-color: black;
  padding:20px;
  color: white;
  text-align: left;
}

h1 {
  font-family: fantasy;
}
</style>
    </head>
    <body>
      <br><br><br>
      <center>
        <h1><img width="5%" src="https://png.pngtree.com/png-vector/20220726/ourmid/pngtree-deer-buck-skull-vector-illustration-png-image_6081873.png">&nbsp;&nbsp; DEEP SEARCH</h1><br><br>
        <form action="search.php" method="get" class="p-3">
          <div class="col-12 col-md-8 container">
            <input type="search" name="q" value="" placeholder="search" id="search-bar">
            <input type="submit" name="search" value="➜" class="fas fa-search btn" id="search-btn">
          </div>
        </form>
 </center>
    </body>
</html>