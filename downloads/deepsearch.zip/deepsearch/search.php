<html>
<style>
body {
    background-color: black;
    color: white;
}
</style>
</html>

<?php
$pdo = new PDO('mysql:host=127.0.0.1;dbname=deepsearch', 'root', '');

$search = $_GET['q'];
$construct = ""; // Initialize $construct variable outside the loop


$searche = explode(" ", $search);

$x = 0;
$params = array();
foreach ($searche as $term) {
    $x++;
    if ($x == 1) {
        $construct .= "title LIKE CONCAT('%',:search$x,'%') OR description LIKE CONCAT('%',:search$x,'%') OR keywords LIKE CONCAT('%',:search$x,'%')";
    } else {
        $construct .= " OR title LIKE CONCAT('%',:search$x,'%') OR description LIKE CONCAT('%',:search$x,'%') OR keywords LIKE CONCAT('%',:search$x,'%')";
    }
    $params[":search$x"] = $term;
}

$results = $pdo->prepare("SELECT * FROM dex WHERE $construct");
$results->execute($params);

if ($results->rowCount() == 0) {
    echo "0 results <hr />";
}else {
    echo $results->rowCount()." results <hr />";
}
echo "<pre>";
foreach ($results->fetchAll() as $result) {
    echo "<h3>".$result["title"]."</h3><br />";
    echo $result["description"]."<br />";
    echo $result["keywords"]."<br />";
    echo "<a href=".$result["url"].">".$result["url"]."</a><br />";
    echo "<hr />";
 }
//print_r($results->fetchAll());


?>