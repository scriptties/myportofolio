<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <head>
        <title>Deep Search</title>
<style>

body {
    background-image: url("https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L3BmLXMxMjQtYWstNTUxNV8zLmpwZw.jpg");
}

#search-bar {
  margin: 0 auto;
  width: 50%;
  height: 30px;
  border-radius: 24px;
  border: 0.5px solid lightgrey;
  padding-right: 100px;
  padding-left: 10px;
}

#search-btn {
  height: 30px;
  border-top-right-radius: 24px;
  border-bottom-right-radius: 24px;
  padding: 10px;
  font-size: 0.6em;
  position: absolute;
  right: 430px;
  border-left: 0.5px solid lightgrey;
}


</style>
    </head>
    <body>
        <img src="ds.png" width="35%" height="auto"><br>
        <form action="search.php" method="get" class="p-3">
          <div class="col-12 col-md-8 container">
            <input type="search" name="q" value="" placeholder="search" id="search-bar">
            <input type="submit" name="search" value="Search" class="fas fa-search btn" id="search-btn">
          </div>
        </form>
    </body>
</html>