<?php

use GuzzleHttp\Client;
use Symfony\Component\CssSelector\CssSelectorConverter;
use Symfony\Component\DomCrawler\Crawler;

define("GOOGLE_URL", "https://www.google.com/search?q=");
require_once(__DIR__ . "/vendor/autoload.php");

$query = "Hamas Israel War";

$request = new Client(['verify' => false]);

$googleRequest = $request->get(GOOGLE_URL . $query);
$responseBody = $googleRequest->getBody();

$converter = new CssSelectorConverter();

$crawler = new Crawler($responseBody);

$element = $crawler->filter("a");
$element->each(function ($item) {
    echo $item->text();
});

// Extract the relevant queries related to the URL's content
$relevantQueries = $crawler->filter('a')
    ->each(function (Crawler $node) {
        return $node->text();
    });

// Output the relevant queries
foreach ($relevantQueries as $query) {
    echo $query . "\n";
}
?>