###############################################################################################################################################
#   IMPORTS
###############################################################################################################################################

import speech_recognition as sr
import pyttsx3
import datetime
import psutil
import requests
import os
import ctypes
import wikipedia
import webbrowser  # New import for opening web search results
import platform
import pygame
import math
import pyaudio

# Initialize text-to-speech engine
engine = pyttsx3.init()

###############################################################################################################################################
#   RECOGNIZER AND SPEECH
###############################################################################################################################################

# Function for text-to-speech
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function for recognizing speech
def get_audio():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-us')
        print(f"You said: {query}\n")
    except Exception as e:
        print(e)
        speak("Sorry, I didn't catch that. Could you please repeat?")
        return "None"
    return query

###############################################################################################################################################
#   GREETINGS
###############################################################################################################################################

# Function for greeting based on time
def greet_user():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good morning! I'm your personal assistant Armageddon")
    elif hour >= 12 and hour < 18:
        speak("Good afternoon! I'm your personal assistant Armageddon")
    else:
        speak("Good evening! I'm your personal assistant Armageddon")

###############################################################################################################################################
#   OPEN APP FUNCTION
###############################################################################################################################################

# Function to open apps
def open_app(app_name):
    if app_name.lower() in app_mapping:
        os.startfile(app_mapping[app_name.lower()])
        speak(f"Opening {app_name}")
    else:
        speak(f"I couldn't find an app named {app_name}")

###############################################################################################################################################
#   BATTERY
###############################################################################################################################################

# Function to get battery percentage
def get_battery_percentage():
    battery = psutil.sensors_battery()
    percentage = battery.percent
    speak(f"Your battery is currently at {percentage} percent.")

###############################################################################################################################################
#   WEATHER
###############################################################################################################################################

# Function to get weather information
def get_weather():
    api_key = "YOUR_OPENWEATHERMAP_API_KEY"  # Replace with your API key
    city = "Your City Name"  # Replace with your city
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    weather_data = response.json()
    description = weather_data['weather'][0]['description']
    temperature = weather_data['main']['temp'] - 273.15  # Convert to Celsius
    speak(f"It's currently {description} in {city} with a temperature of {temperature:.1f} degrees Celsius.")

###############################################################################################################################################
#   BRIGHTNESS AND VOLUMES ADJUSTMENTS
###############################################################################################################################################

# Function to adjust brightness
def adjust_brightness(change):
    c = ctypes.windll.user32.GetDC(0)
    ctypes.windll.user32.SetBrightness(c, change)

# Function to adjust volume
def adjust_volume(change):
    volume = ctypes.windll.winmm.waveOutGetVolume(None)[0]
    new_volume = max(0, min(volume + change, 100))
    ctypes.windll.winmm.waveOutSetVolume(None, new_volume, new_volume)

###############################################################################################################################################
#   QUESTIONS
###############################################################################################################################################

def answer_meaning(query):
    try:
        summary = wikipedia.summary(query, sentences=2)
        speak(f"According to Wikipedia, {summary}")
    except wikipedia.exceptions.DisambiguationError as e:
        speak("Could you please clarify which one you mean? Here are some options:")
        for option in e.options:
            speak(option)
    except wikipedia.exceptions.PageError:
        speak("I couldn't find a Wikipedia article for that. Let me search the web for you.")
        url = f"https://www.google.com/search?q=define+{query}"
        webbrowser.open(url)  # Open the search results in a web browser

###############################################################################################################################################
#   DEVICE SPECS
###############################################################################################################################################

def get_device_specs():
    """Gathers and announces the current device's specifications."""

    # Operating system
    os_name = platform.system()
    os_version = platform.release()

    # CPU (basic information)
    cpu_name = platform.processor()

    # RAM (approximate value)
    total_ram = round(psutil.virtual_memory().total / (1024 * 1024 * 1024), 2)  # GB

    # Announce specifications
    speak(f"I'm running on {os_name} version {os_version}.")
    speak(f"My processor is a {cpu_name}.")
    speak(f"I have approximately {total_ram} GB of RAM available.")

###############################################################################################################################################
#   MAPPING
###############################################################################################################################################

# Map app names to their file paths
app_mapping = {
    "chrome": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",  # Replace with your Chrome path
    "notepad": "C:\\Windows\\System32\\notepad.exe",
    "word": "C:\\",
    "powerpoint": "C:\\",
    "excel": "C:\\",
    "settings": "C:\\",
    # Add more apps
}


while True:

    greet_user()
    get_device_specs()
    get_battery_percentage()
    current_time = datetime.datetime.now().strftime("%I:%M %p")
    speak(f"and the time is {current_time}")
    speak("Please feel free to ask me anything, the definition of a word, a question, to open an app, or adjust brightness and volume, I can help you with anything aslong as it is in my range of capabilities.")
    speak("I'm listening...")

    query = get_audio().lower()


    if "open" in query:
        app_name = query.split("open")[-1].strip()
        open_app(app_name)

    if "battery percentage" in query:
        get_battery_percentage()
    
    if "device specs" in query:
        get_device_specs()
    
    if "brightness" in query:
        direction = query.split("brightness")[0].strip()
        if direction == "increase":
            adjust_brightness(10)
        elif direction == "decrease":
            adjust_brightness(-10)

    if "volume" in query:
        direction = query.split("volume")[0].strip()
        if direction == "increase":
            adjust_volume(10)
        elif direction == "decrease":
            adjust_volume(-10)

    if "weather" in query:
        get_weather()

    if "time" in query:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The time is {current_time}")

    if "what is" in query or "define" in query or "meaning of" in query:
        answer_meaning(query.split("what is")[-1].strip() or query.split("define")[-1].strip() or query.split("meaning of")[-1].strip())
